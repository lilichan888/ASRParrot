# Training Guide — Build a Thai ASR Testing "Parrot" Bot

**Who this is for:** anyone on the team, even if you have never built an Amazon
Connect flow or run a Python script before. Follow the steps in order. Every
step tells you exactly what to click, type, or copy.

**What you will build:** a phone number you can call. When you call it, a simple
voice bot ("the parrot") keeps saying *"กรุณาพูด"* (please speak). You
read Thai test phrases out loud, one at a time. Behind the scenes, Amazon
Connect's speech-to-text (Deepgram) writes down what it heard. Afterwards you
run a script that compares what the machine heard against the phrases you were
supposed to say, and it gives you an accuracy score (CER / WER).

**Why "parrot"?** The bot does NOT answer questions or help the caller. It only
paces you through the list. Its single job is to make the platform transcribe
your speech so we can measure how good the Thai speech recognition is.

---

## The big picture (read this once)

```
You read a phrase   ─►  Amazon Connect Agentic Voice
(from references)        • Deepgram turns your speech into text  (the "guess")
                         • Bot replies "กรุณาพูด" and waits
                                 │
                                 ▼
                    The text is saved automatically in a
                    CloudWatch log (no extra setup to capture it)
                                 │
                                 ▼
                    You run a Python script that compares
                    "what you said" vs "what the machine heard"
                                 │
                                 ▼
                    Accuracy report:  CER / WER  (lower = better)
```

Two speech-to-text engines actually run on the same call:
- **Deepgram** — the live engine Agentic Voice uses. This is the one we test.
- **Amazon Transcribe** — runs separately (Contact Lens) on the recording. We
  can compare the two later, but Deepgram is the star.

---

## What you need before you start

1. Access to an **Amazon Connect instance** (someone on the team has this) with
   **Amazon Q in Connect** enabled.
2. Permission to open the **AWS Console** for that account, and to use the AWS
   **CLI** on your laptop (ask your admin if unsure).
3. A phone to make a real call.
4. **Python 3** installed on your laptop. Check by opening Terminal and typing:
   ```bash
   python3 --version
   ```
   If you see a version number (e.g. `Python 3.11`), you are good.

Write down these three values from your instance (you will reuse them a lot):

| Name | Looks like | Where to find it |
|---|---|---|
| Instance ID | `e038b142-d31e-4844-...` | Connect console → your instance → the ID in the ARN |
| Region | `ap-southeast-1` (or `ap-southeast-3` for Jakarta) | top-right of the AWS console |
| AWS CLI profile | `myprofile` | whatever your admin set up; test with `aws sts get-caller-identity` |

> Tip: keep a scratch note open and paste each ID you collect into it. You will
> collect a few ARNs along the way.

---

## PART A — Create the parrot bot (AI agent)

This part is done in the **web console** (it cannot be scripted).

### Step 1 — Open the AI agents page
1. Go to the **Amazon Connect** console and open your instance.
2. In the left menu, find **Amazon Q** (sometimes shown as **Q in Connect**).
3. Click **AI agents**.

### Step 2 — Create the agent
1. Click **Create AI agent** (or **Create agent**).
2. Choose the type that runs voice self-service — usually shown as
   **Self-service** / **Agentic Voice**.
3. Name it exactly: `Thai-ASR-Parrot`
4. For the **system prompt / instructions**, open the file
   `agent/Thai_Parrot_Prompt.txt` from this project, copy **everything**
   inside it, and paste it into the prompt box.
5. Language / locale: choose **Thai (th-TH)**.
6. Leave speech-to-text as the default (Deepgram / Agentic Voice default).
7. Click **Save**, then **Publish**.

### Step 3 — Copy two ARNs (very important)
After publishing, find and copy these into your scratch note:
- **Wisdom Assistant ARN** — looks like `arn:aws:wisdom:...:assistant/xxxx`
- **AI agent version ARN** — looks like
  `arn:aws:wisdom:...:ai-agent/<assistantId>/<agentId>:$LATEST`

> If you cannot see the assistant ARN, open **Q in Connect → Assistants** and
> copy it from there. The part after `assistant/` is your **assistant ID** —
> you will need it for scoring at the very end.

---

## PART B — Find the Thai voice + Lex bot alias

The contact flow needs to know (a) which voice to speak with and (b) which Lex
bot fronts the Agentic Voice bot. Both are read from dropdowns in the console.

### Step 4 — Get the Thai voice name
1. Create a new (empty) contact flow, or open any existing one.
2. Drag in a **Set voice** block.
3. Set **Voice Provider** = **Amazon Connect agentic voice**.
4. Set **Language** = **Thai**.
5. Note the **voice name** shown in the dropdown (write it down exactly). This
   is the value the flow needs. It is not published anywhere else, so you must
   read it here.

### Step 5 — Build the Thai Lex bot and get its alias ARN
Agentic Voice is delivered through a **Lex V2 bot alias** with a **th_TH**
locale. If your team already has a shared Agentic Voice Lex bot with a th_TH
locale, just copy its alias ARN and skip to Step 6. Otherwise, build one — it is
a tiny "passthrough" bot (no custom intents), and the **easiest, safest way is
through the Connect console** because it handles association and tagging for you
(see the two gotchas below).

**Option A — build it in the Connect console (recommended):**
1. In your Connect instance, go to **Flows** → scroll to the **Amazon Lex**
   section → **Add Amazon Lex Bot** / **Create a new bot**.
2. Create a Lex V2 bot (name e.g. `thai_ai_id`), language/locale
   **Thai (th_TH)**.
3. In the locale's **Generative AI / NLU** settings, turn on **Assisted NLU**
   and set it to **Primary** (Agentic Voice requires this), and set the speech
   model to **Advanced**.
4. Add the intent **`AMAZON.QInConnectIntent`** (this is the passthrough intent
   that routes to Q in Connect). Point it at your Q in Connect assistant.
5. **Build** the locale, create a **version**, and create a **Prod** alias on
   that version.
6. Copy the alias ARN — looks like `arn:aws:lex:...:bot-alias/<botId>/<aliasId>`.

**Option B — build it with the AWS CLI:** see the full command recipe in
[APPENDIX A — Build the Lex bot from scratch (CLI)](#appendix-a--build-the-lex-bot-from-scratch-cli).

> ⚠️ **Two gotchas if you build the bot by CLI (or outside the Connect
> console).** The console does these two things for you automatically; the CLI
> does NOT. Miss either one and the bot looks broken in Connect:
>
> 1. **Associate the bot with the instance** — otherwise it does **not appear**
>    in Flows → Conversational AI at all:
>    ```bash
>    aws connect associate-bot --region <region> --instance-id <instance-id> \
>      --lex-v2-bot "AliasArn=arn:aws:lex:<region>:<acct>:bot-alias/<botId>/<aliasId>"
>    ```
> 2. **Tag BOTH the bot and its alias** with `AmazonConnectEnabled=True` —
>    otherwise the bot shows up but clicking it errors with *"You can't access
>    this page — The Conversational AI bot does not have the required tag set."*
>    ```bash
>    aws lexv2-models tag-resource --region <region> \
>      --resource-arn "arn:aws:lex:<region>:<acct>:bot/<botId>" \
>      --tags '{"AmazonConnectEnabled":"True"}'
>    aws lexv2-models tag-resource --region <region> \
>      --resource-arn "arn:aws:lex:<region>:<acct>:bot-alias/<botId>/<aliasId>" \
>      --tags '{"AmazonConnectEnabled":"True"}'
>    ```

---

## PART C — Set up and import the contact flow

Now you have four values. You will paste them into the flow file, then upload
the flow.

### Step 6 — Fill in the four placeholders
1. Open `connect/Thai_Parrot_Flow.json` in a text editor.
2. Use Find & Replace to swap each placeholder for your real value:

| Find this placeholder | Replace with |
|---|---|
| `REPLACE_WITH_WISDOM_ASSISTANT_ARN` | Wisdom Assistant ARN (Step 3) |
| `REPLACE_WITH_AI_AGENT_ARN` | AI agent version ARN (Step 3) — appears **twice**, replace both |
| `REPLACE_WITH_LEX_BOT_ALIAS_ARN` | Lex bot alias ARN (Step 5) |
| `REPLACE_WITH_THAI_AGENTIC_VOICE` | Thai voice name (Step 4) |

3. Save the file.

> Double-check there are no `REPLACE_WITH_` words left. Search the file for
> `REPLACE_` to be sure.

### Step 7 — Upload the flow (using the AWS CLI)
Open Terminal and run this, replacing the two values in `< >`:
```bash
export AWS_PROFILE=<your-profile>
aws connect create-contact-flow \
  --region <your-region> \
  --instance-id <your-instance-id> \
  --name "Thai-ASR-Parrot-Flow" \
  --type CONTACT_FLOW \
  --content file://connect/Thai_Parrot_Flow.json
```
- Run it from inside the `_Thai-ASR-Parrot` folder so the `file://` path
  works. (In Terminal, `cd` into that folder first.)
- On success you get back a **ContactFlowId**. Copy it.

> Prefer clicking? You can instead go to **Routing → Flows → Create flow →
> (top-right arrow) → Import flow**, choose the JSON file, then **Publish**.

### Step 8 — Publish the flow
- If you used the console import, click **Publish**.
- If you used the CLI, publish it too: open the flow in the console once and
  click **Publish** (this makes the latest content live).

---

## PART D — Attach a phone number

### Step 9 — Point a number at your flow
1. In the console: **Channels → Phone numbers**.
2. Pick a spare number (or claim a new Thai `+62` number).
3. Set its **Contact flow / IVR** to **Thai-ASR-Parrot-Flow**.
4. Save. This number is now your test hotline.

> CLI alternative:
> ```bash
> aws connect associate-phone-number-contact-flow \
>   --region <your-region> \
>   --instance-id <your-instance-id> \
>   --phone-number-id <PHONE_NUMBER_ID> \
>   --contact-flow-id <FLOW_ID_FROM_STEP_7>
> ```

---

## PART E — Turn on the transcript log (one-time)

The scoring script reads Deepgram's text from a CloudWatch log tied to your
assistant. Usually this is already on. Confirm the log group
`/aws/wisdom/assistant/<your-assistant-id>` exists in **CloudWatch → Log
groups**.

- If it exists: nothing to do.
- If it does NOT exist: ask your admin to enable **Q in Connect transcript log
  delivery** for the assistant (a one-time setup). Without it, the call happens
  fine but there is nothing to score.

---

## PART F — Make a test call

### Step 10 — Call and read the phrases
1. Open `references/references.csv` (or `references.txt`) so you can read the
   phrases.
2. Call your hotline number.
3. You will hear **"กรุณาเริ่มพูด"** (please start speaking).
4. Read **phrase 1**, then pause and wait. The bot says **"กรุณาพูด"**.
5. Read **phrase 2**, pause, wait. Continue down the list.
6. When done, say **"berhenti"** or **"sudah selesai"** to end, or just hang up.

**Tips for a clean test:**
- Speak numbers naturally in **Thai** (e.g. *"ศูนย์ แปด หนึ่ง สอง..."*,
  *"หนึ่งแสนห้าหมื่นบาท"*). The scorer understands Thai numbers.
- One phrase per turn. Pause clearly. Wait for the cue before the next one.
- You do NOT have to read every phrase. Partial reads still score fine.
- **For Thai, read the CER (Character Error Rate) column, not WER.** Thai is
  written without spaces between words, so word-level WER is not meaningful;
  CER is the reliable accuracy metric.

### Step 11 — Get the Contact ID
1. In the console: **Analytics → Contact search** (or **Metrics & quality →
   Contact search**).
2. Find your call (sort by most recent).
3. Copy the **Contact ID** (a long id like `9ce7db3d-...`). Write it down.

---

## PART G — Score the results (on your laptop)

### Step 12 — One-time setup of the scoring tool
In Terminal, from inside the project:
```bash
cd _Thai-ASR-Parrot/scoring
python3 -m venv .venv
./.venv/bin/pip install -r requirements.txt
```
This creates a private Python environment and installs the 3 libraries the
scripts need. You only do this once.

### Step 13 — Run the Deepgram accuracy score
Replace the two values in `< >` with your assistant ID and contact ID:
```bash
./.venv/bin/python wer_cer.py \
  --refs-csv ../references/references.csv \
  --hyps-cloudwatch /aws/wisdom/assistant/<YOUR-ASSISTANT-ID> \
  --contact-id <YOUR-CONTACT-ID> \
  --region <your-region> \
  --align best-match \
  --number-mode words2digits \
  --out-prefix results/Thai-CER-WER_<YOUR-CONTACT-ID>
```
This prints a summary and writes a CSV + XLSX into the `results/` folder.

### Step 14 — Read the score
On screen you will see something like:
```
  CER  macro (avg per phrase) : 6.20%
  DIGITS-NORMALIZED
    CER  macro : 3.10%
```
How to read it:
- **CER** = Character Error Rate. **Lower is better.** 0% is perfect.
- Look at the **number-normalized** (digits-normalized) numbers as the fair
  score. Deepgram may spell a phone number out as words; normalizing turns both
  sides into digits so you measure real recognition, not formatting.
- Open the `.xlsx` in `results/` to see each phrase side by side: what you said
  vs what the machine heard. A `Captured? = MISSING` row means that phrase was
  not spoken or not clearly matched.

> **Sanity check:** if a phrase shows a CER far above 100%, it usually means the
> phrases got mis-aligned (you skipped one, or had a chat with the bot instead
> of reading the script). Ignore/redo that call rather than trusting the number.

### Step 15 (optional) — Compare Deepgram vs Amazon Transcribe
Contact Lens saves an analysis JSON in the instance's S3 bucket under
`Analysis/Voice/.../<contactId>_analysis_*.json`. Download it, then:
```bash
./.venv/bin/python compare_engines.py \
  --refs-csv ../references/references.csv \
  --deepgram-cloudwatch /aws/wisdom/assistant/<YOUR-ASSISTANT-ID> \
  --contact-id <YOUR-CONTACT-ID> \
  --transcribe-json <path-to-analysis.json> \
  --region <your-region> \
  --out-prefix results/Thai-CER-WER_<YOUR-CONTACT-ID>
```

### Step 16 (optional) — Combine several testers' calls
After several people each score their own call (each producing a
`results/Thai-CER-WER_<contactId>.csv`), pool them into one summary:
```bash
./.venv/bin/python rollup.py
```
It writes `results/Thai-CER-WER_ROLLUP.csv` and `.xlsx` with a per-call
breakdown plus a pooled average.

---

## Quick reference — the whole flow on one screen

1. **AI agent** `Thai-ASR-Parrot` (paste prompt, language th-TH, publish) → copy 2 ARNs.
2. **Voice name** (Set voice → agentic → Thai) + **Lex alias ARN**.
3. **Fill 4 placeholders** in the flow JSON → `create-contact-flow` → **publish**.
4. **Attach a phone number** to the flow.
5. **Confirm** the CloudWatch transcript log exists.
6. **Call**, read phrases, note the **Contact ID**.
7. **Score**: `wer_cer.py --number-mode words2digits` → read CER (lower is better).

---

## Common problems and fixes

| Symptom | Likely cause | Fix |
|---|---|---|
| Call connects but bot is silent | Voice name or Lex alias wrong in the flow | Re-check Steps 4/5, re-fill placeholders, re-import + publish |
| Lex bot not listed in Flows → Conversational AI | Bot not associated with the instance (happens when built by CLI) | Run `aws connect associate-bot ...` (Step 5 gotcha 1) |
| Clicking the bot errors: *"does not have the required tag set"* | Bot/alias missing the `AmazonConnectEnabled=True` tag (happens when built by CLI) | Tag BOTH the bot and the alias (Step 5 gotcha 2) |
| Amazon Connect AI agent toggle disabled: *"...bot created outside Connect console..."* | EXPECTED for imported / Lex-console / CLI-built bots — the toggle is console-created-bots only (documented) | Not a problem: the QInConnect config is already in the intent. Use the `Prod` alias as-is; verify with a test call. Edit config via the Lex console if ever needed (Appendix B) |
| `create-contact-flow` errors on a placeholder | A `REPLACE_WITH_` was left in the file | Search the JSON for `REPLACE_` and fix |
| Script says "0 hypotheses" | Wrong assistant ID, wrong contact ID, or the log isn't set up | Recheck the assistant ID and that CloudWatch log group exists |
| CER looks huge (>100%) | Phrases mis-aligned / you chatted instead of reading | Redo the call; read one phrase per turn with clear pauses |
| Numbers score badly on raw CER | Deepgram spelled numbers as words | Read the **number-normalized** column — that is the fair score |
| `python3: command not found` | Python not installed | Install Python 3, then retry |

---

## Notes for the trainer

- The AI agent step is the only part that must be done by hand in the console;
  the flow and number are CLI-friendly and repeatable.
- The **key language fact** for Thai: callers say numbers in Thai
  (satu, dua, tiga...). `num_normalize.py` already knows Thai numbers, so
  always pass `--number-mode words2digits` and read the number-normalized score.
- Keep the reference list short enough to read in one call (the included 21
  phrases take ~3-4 minutes).
- Score calls within a few days — CloudWatch and Contact Lens data have
  retention windows.

---

## APPENDIX A — Build the Lex bot from scratch (CLI)

Use this if you prefer the CLI over the Connect console (Step 5, Option B). This
recreates a minimal Q-in-Connect passthrough bot with a **th_TH** locale,
mirroring the reference `tcb_ai_vi` bot. Replace every `<...>` with your values.

> Prefer the console (Step 5, Option A) if you can — it does the **associate**
> and **tag** steps (A6–A7 below) automatically. The two most common mistakes
> when using the CLI are forgetting those two steps.

Set some shell variables first:
```bash
export AWS_PROFILE=<your-profile>
R=<your-region>                 # e.g. ap-southeast-1
ACCT=<your-account-id>
INSTANCE=<your-connect-instance-id>
ASSISTANT_ARN=<your-q-in-connect-assistant-arn>   # arn:aws:wisdom:<R>:<ACCT>:assistant/<id>
# The service-linked role Lex uses with Connect (already exists in most accounts):
ROLE="arn:aws:iam::$ACCT:role/aws-service-role/lexv2.amazonaws.com/AWSServiceRoleForLexV2Bots_AmazonConnect_$ACCT"
```

**A1 — Create the bot:**
```bash
aws lexv2-models create-bot --region $R \
  --bot-name "thai_ai_id" \
  --description "Thai self-service passthrough bot (Q-in-Connect) — Agentic Voice" \
  --role-arn "$ROLE" \
  --data-privacy '{"childDirected":false}' \
  --idle-session-ttl-in-seconds 300
# note the returned botId -> B=<botId>
```

**A2 — Create the th_TH locale** (Assisted NLU = Primary is required by Agentic Voice):
```bash
aws lexv2-models create-bot-locale --region $R --bot-id $B --bot-version DRAFT \
  --locale-id th_TH \
  --nlu-intent-confidence-threshold 0.4 \
  --generative-ai-settings '{"runtimeSettings":{"nluImprovement":{"enabled":true,"assistedNluMode":"Primary"}}}'
```

**A3 — Set the Advanced speech model** (once the locale exists):
```bash
aws lexv2-models update-bot-locale --region $R --bot-id $B --bot-version DRAFT --locale-id th_TH \
  --nlu-intent-confidence-threshold 0.4 \
  --generative-ai-settings '{"runtimeSettings":{"nluImprovement":{"enabled":true,"assistedNluMode":"Primary"}}}' \
  --speech-recognition-settings '{"speechModelPreference":"Advanced"}'
```

**A4 — Create the Q-in-Connect passthrough intent** (`FallbackIntent` is auto-created with the locale):
```bash
aws lexv2-models create-intent --region $R --bot-id $B --bot-version DRAFT --locale-id th_TH \
  --intent-name "AmazonQinConnect" \
  --parent-intent-signature "AMAZON.QInConnectIntent" \
  --fulfillment-code-hook '{
      "enabled": false, "active": true,
      "postFulfillmentStatusSpecification": {
        "successResponse": {
          "messageGroups": [ {"message": {"plainTextMessage": {"value": "((x-amz-lex:q-in-connect-response))"}}} ],
          "allowInterrupt": true
        },
        "successNextStep": {"dialogAction": {"type": "EndConversation"}},
        "failureNextStep": {"dialogAction": {"type": "EndConversation"}},
        "timeoutNextStep": {"dialogAction": {"type": "EndConversation"}}
      }
    }' \
  --q-in-connect-intent-configuration "{\"qInConnectAssistantConfiguration\":{\"assistantArn\":\"$ASSISTANT_ARN\"}}"
```

**A5 — Build the locale, create a version, create the Prod alias:**
```bash
aws lexv2-models build-bot-locale --region $R --bot-id $B --bot-version DRAFT --locale-id th_TH
# wait until botLocaleStatus = Built, then:
aws lexv2-models create-bot-version --region $R --bot-id $B \
  --bot-version-locale-specification '{"th_TH":{"sourceBotVersion":"DRAFT"}}'
# wait until the version is Available (say it is version 1), then:
aws lexv2-models create-bot-alias --region $R --bot-id $B \
  --bot-alias-name "Prod" --bot-version "1" \
  --bot-alias-locale-settings '{"th_TH":{"enabled":true}}'
# note the returned botAliasId -> A=<aliasId>
```

**A6 — Associate the bot with the Connect instance** (or it won't appear in Flows):
```bash
aws connect associate-bot --region $R --instance-id $INSTANCE \
  --lex-v2-bot "AliasArn=arn:aws:lex:$R:$ACCT:bot-alias/$B/$A"
```

**A7 — Tag the bot AND alias** (or the console errors with "required tag not set"):
```bash
aws lexv2-models tag-resource --region $R \
  --resource-arn "arn:aws:lex:$R:$ACCT:bot/$B" --tags '{"AmazonConnectEnabled":"True"}'
aws lexv2-models tag-resource --region $R \
  --resource-arn "arn:aws:lex:$R:$ACCT:bot-alias/$B/$A" --tags '{"AmazonConnectEnabled":"True"}'
```

**A8 — The alias ARN for the contact flow** (`REPLACE_WITH_LEX_BOT_ALIAS_ARN`):
```
arn:aws:lex:$R:$ACCT:bot-alias/$B/$A
```

Notes:
- The intent's `assistantArn` just has to be a **valid** Q-in-Connect assistant
  in the account for the bot to build. The specific AI agent used on a call is
  chosen by the contact flow's `x-amz-lex:q-in-connect:ai-agent-arn` session
  attribute, not by this field — so you can point it at any assistant now and
  re-point it later (update the intent, rebuild the locale, cut a new version,
  move the alias).
- This bot has **no custom intents or slots** — it is purely a passthrough to Q
  in Connect. Do not add utterances; Assisted NLU + the QInConnect intent do the
  work.

---

## APPENDIX B — Cloning a bot for another language by IMPORT

A quick way to make (say) a Thai bot is to **export the Thai Lex bot and
import it** as a new bot, then change the locale to `th_TH`.

**What import brings over:** the bot definition, the locale, and the
`AMAZON.QInConnectIntent` — including its Q-in-Connect config (assistant ARN)
and the passthrough fulfillment hook. All of it comes across correctly.

**What import does NOT bring over:** the **published version** and the
**aliases**. A freshly imported bot has only `DRAFT` and the auto-created
`TestBotAlias`. So, as with a CLI build, you still need to publish a **version**
and create a **`Prod` alias**, then **tag** and **associate** it (the A5–A7
steps in Appendix A). Point your contact flow at that `Prod` alias.

### Expected: the "Amazon Connect AI agent" toggle stays greyed out (this is normal)

In **Connect → Flows → Conversational AI**, when you open an *imported* bot and
look at the *Amazon Connect AI agent* section of the QInConnect intent, the
generative-AI toggle is **disabled** with:

> *"Amazon Connect AI agent is not supported for the Conversational AI bot
> created outside Connect console. Please go to Lex console to add Amazon
> Connect AI agent configuration."*

**This is documented, expected behavior — not a bug, and it does not break your
bot.** Per AWS docs, that console toggle is offered **only for bots created
directly in the Amazon Connect admin console**. Any bot that arrived another way
(imported, or built via the Lex console / CLI) shows this message.
Source: <https://docs.aws.amazon.com/connect/latest/adminguide/create-qic-intent-connect.html>

Crucially, the toggle is just a **shortcut for writing the QInConnect intent
config**. An imported bot **already has that config** (it came across in the
import), so nothing is actually missing. Publishing a version + `Prod` alias or
tagging does **not** turn the toggle on — origin is what the console checks, and
that cannot be changed after the fact.

### What to do about it

- **Recommended — just use the bot as-is.** The QInConnect config is already
  present on the published version your `Prod` alias serves, so the bot routes
  to Q in Connect correctly at runtime. Reference the `Prod` alias ARN in your
  contact flow's Lex block and place a test call — it works the same as the
  Thai bot. The greyed toggle is cosmetic in this case; you can ignore it.
- **If you ever need to CHANGE the AI-agent config on an imported bot:** do it
  from the **Amazon Lex console** (open the bot → the `AmazonQinConnect` intent →
  Amazon Q in Connect settings), then build + publish a new version and move the
  `Prod` alias. The Connect console won't let you edit it, but the Lex console
  will.
- **If you specifically want the Connect toggle to be active** (purely for a
  tidier console experience, not for functionality): the only way is to **build
  the bot fresh through the Connect console** ("Add Amazon Lex bot" → create it
  there) instead of importing. Then Connect records it as console-created.

> Bottom line: for an import-cloned (or CLI-built) bot, the greyed toggle is
> expected and harmless — the Q-in-Connect config is already in the intent.
> Verify with a test call rather than trusting the toggle's state.
