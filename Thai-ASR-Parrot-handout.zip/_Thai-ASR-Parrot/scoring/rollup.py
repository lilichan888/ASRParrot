#!/usr/bin/env python3
"""
rollup.py — Combine multiple per-call Thai-CER-WER_<cid>.csv files into one
summary across all testers/calls.

Each per-call CSV (produced by compare_engines.py) has these columns:
  Sequence, GroundTruth,
  Deepgram ASR, DG CER raw(%), DG WER raw(%),
  DG CER num-normalized(%), DG WER num-normalized(%), DG Captured?,
  Transcribe ASR, AT CER raw(%), AT WER raw(%),
  AT CER num-normalized(%), AT WER num-normalized(%), AT Captured?

This script:
  * reads every per-call CSV (all results/Thai-CER-WER_*.csv, or an explicit
    list of files passed as arguments)
  * keeps ONLY phrases the tester actually read (Captured? == yes) — unread
    reference phrases are ignored in the averages
  * reports, per call and pooled across all calls:
      - phrases scored
      - macro CER/WER (average of per-phrase scores) for Deepgram & Transcribe,
        both raw and num-normalized
  * writes:
      - Thai-CER-WER_ROLLUP.csv     (per-call summary, one row per call)
      - Thai-CER-WER_ROLLUP.xlsx    (Per-Call sheet + Pooled sheet)

Note on averaging: we use the MACRO average (mean of per-phrase percentages),
matching the per-call console banner from compare_engines.py. The pooled row is
the macro average over EVERY matched phrase from ALL calls combined, so a call
with more phrases contributes proportionally more — this is the honest
"across all testers" number.

Usage
-----
  ./.venv/bin/python rollup.py
  ./.venv/bin/python rollup.py results/Thai-CER-WER_abc.csv results/Thai-CER-WER_def.csv
  ./.venv/bin/python rollup.py --glob 'results/Thai-CER-WER_*.csv' --out-prefix results/Thai-CER-WER_ROLLUP
"""

import argparse
import csv
import glob
import os
import re
import sys

# CSV column names (must match compare_engines.py header)
COL_SEQ = "Sequence"
COL_DG_CER_RAW = "DG CER raw(%)"
COL_DG_WER_RAW = "DG WER raw(%)"
COL_DG_CER_NUM = "DG CER num-normalized(%)"
COL_DG_WER_NUM = "DG WER num-normalized(%)"
COL_DG_CAP = "DG Captured?"
COL_AT_CER_RAW = "AT CER raw(%)"
COL_AT_WER_RAW = "AT WER raw(%)"
COL_AT_CER_NUM = "AT CER num-normalized(%)"
COL_AT_WER_NUM = "AT WER num-normalized(%)"
COL_AT_CAP = "AT Captured?"


def _pct_to_float(s):
    """'7.30%' -> 7.30 ; '' or 'n/a' -> None."""
    if s is None:
        return None
    s = s.strip().rstrip("%").strip()
    if not s or s.lower() in ("n/a", "na", "none"):
        return None
    try:
        return float(s)
    except ValueError:
        return None


def _mean(vals):
    vals = [v for v in vals if v is not None]
    return (sum(vals) / len(vals)) if vals else None


def _cid_from_path(path):
    base = os.path.basename(path)
    m = re.match(r"Thai-CER-WER_(.+)\.csv$", base)
    return m.group(1) if m else base


class CallStats:
    """Per-phrase captured values for one call, per engine/metric."""

    def __init__(self, cid):
        self.cid = cid
        self.dg_total = 0
        self.dg_captured = 0
        self.at_total = 0
        self.at_captured = 0
        # matched-only per-phrase percentage lists
        self.dg_cer_raw = []
        self.dg_wer_raw = []
        self.dg_cer_num = []
        self.dg_wer_num = []
        self.at_cer_raw = []
        self.at_wer_raw = []
        self.at_cer_num = []
        self.at_wer_num = []

    def add_row(self, row):
        dg_cap = (row.get(COL_DG_CAP, "") or "").strip().lower() == "yes"
        at_cap = (row.get(COL_AT_CAP, "") or "").strip().lower() == "yes"
        self.dg_total += 1
        self.at_total += 1
        if dg_cap:
            self.dg_captured += 1
            self.dg_cer_raw.append(_pct_to_float(row.get(COL_DG_CER_RAW)))
            self.dg_wer_raw.append(_pct_to_float(row.get(COL_DG_WER_RAW)))
            self.dg_cer_num.append(_pct_to_float(row.get(COL_DG_CER_NUM)))
            self.dg_wer_num.append(_pct_to_float(row.get(COL_DG_WER_NUM)))
        if at_cap:
            self.at_captured += 1
            self.at_cer_raw.append(_pct_to_float(row.get(COL_AT_CER_RAW)))
            self.at_wer_raw.append(_pct_to_float(row.get(COL_AT_WER_RAW)))
            self.at_cer_num.append(_pct_to_float(row.get(COL_AT_CER_NUM)))
            self.at_wer_num.append(_pct_to_float(row.get(COL_AT_WER_NUM)))


def read_call(path):
    cs = CallStats(_cid_from_path(path))
    with open(path, encoding="utf-8-sig", newline="") as f:
        rd = csv.DictReader(f)
        missing = [c for c in (COL_DG_CAP, COL_AT_CAP, COL_DG_CER_NUM) if c not in rd.fieldnames]
        if missing:
            print(f"  WARNING: {os.path.basename(path)} missing columns {missing}; skipping.")
            return None
        for row in rd:
            cs.add_row(row)
    return cs


def fmt(v):
    return f"{v:.2f}%" if v is not None else "n/a"


def main():
    ap = argparse.ArgumentParser(description="Roll up per-call Thai ASR CSVs into one summary.")
    ap.add_argument("files", nargs="*", help="Explicit per-call CSV paths (default: --glob)")
    ap.add_argument("--glob", default="results/Thai-CER-WER_*.csv",
                    help="Glob for per-call CSVs when no explicit files are given")
    ap.add_argument("--out-prefix", default="results/Thai-CER-WER_ROLLUP")
    args = ap.parse_args()

    paths = args.files if args.files else sorted(glob.glob(args.glob))
    # never roll a previous rollup into a new one
    paths = [p for p in paths if "ROLLUP" not in os.path.basename(p)]
    if not paths:
        sys.exit(f"No per-call CSVs found (glob: {args.glob}).")

    calls = []
    for p in paths:
        cs = read_call(p)
        if cs is not None:
            calls.append(cs)
    if not calls:
        sys.exit("No readable per-call CSVs.")

    # ---- console + per-call rows ----
    print("=" * 92)
    print("  Thai ASR — MULTI-CALL ROLL-UP (Deepgram vs Amazon Transcribe)")
    print("=" * 92)
    print(f"  Calls combined: {len(calls)}")
    print("  (num-normalized = fair recognition; raw inflated by Deepgram spelling digits as words)")
    print("  " + "-" * 90)
    print(f"  {'Contact':<40}{'DG phr':>7}{'DG CER num':>12}{'DG WER num':>12}{'AT CER num':>12}{'AT WER num':>12}")
    print("  " + "-" * 90)

    per_call_rows = []
    for cs in calls:
        dg_cer_num = _mean(cs.dg_cer_num)
        dg_wer_num = _mean(cs.dg_wer_num)
        at_cer_num = _mean(cs.at_cer_num)
        at_wer_num = _mean(cs.at_wer_num)
        print(f"  {cs.cid:<40}{cs.dg_captured:>7}{fmt(dg_cer_num):>12}{fmt(dg_wer_num):>12}{fmt(at_cer_num):>12}{fmt(at_wer_num):>12}")
        per_call_rows.append({
            "Contact": cs.cid,
            "DG phrases": cs.dg_captured,
            "AT phrases": cs.at_captured,
            "DG CER raw(%)": _mean(cs.dg_cer_raw),
            "DG WER raw(%)": _mean(cs.dg_wer_raw),
            "DG CER num(%)": dg_cer_num,
            "DG WER num(%)": dg_wer_num,
            "AT CER raw(%)": _mean(cs.at_cer_raw),
            "AT WER raw(%)": _mean(cs.at_wer_raw),
            "AT CER num(%)": at_cer_num,
            "AT WER num(%)": at_wer_num,
        })

    # ---- pooled (all matched phrases from all calls) ----
    pool_dg_cer_raw = [v for cs in calls for v in cs.dg_cer_raw]
    pool_dg_wer_raw = [v for cs in calls for v in cs.dg_wer_raw]
    pool_dg_cer_num = [v for cs in calls for v in cs.dg_cer_num]
    pool_dg_wer_num = [v for cs in calls for v in cs.dg_wer_num]
    pool_at_cer_raw = [v for cs in calls for v in cs.at_cer_raw]
    pool_at_wer_raw = [v for cs in calls for v in cs.at_wer_raw]
    pool_at_cer_num = [v for cs in calls for v in cs.at_cer_num]
    pool_at_wer_num = [v for cs in calls for v in cs.at_wer_num]
    dg_phr_total = sum(cs.dg_captured for cs in calls)
    at_phr_total = sum(cs.at_captured for cs in calls)

    print("  " + "-" * 90)
    print(f"  {'POOLED (all calls)':<40}{dg_phr_total:>7}"
          f"{fmt(_mean(pool_dg_cer_num)):>12}{fmt(_mean(pool_dg_wer_num)):>12}"
          f"{fmt(_mean(pool_at_cer_num)):>12}{fmt(_mean(pool_at_wer_num)):>12}")
    print("=" * 92)

    # ---- write CSV (per-call rows + pooled row) ----
    out_csv = args.out_prefix + ".csv"
    os.makedirs(os.path.dirname(out_csv) or ".", exist_ok=True)
    fieldnames = [
        "Contact", "DG phrases", "AT phrases",
        "DG CER raw(%)", "DG WER raw(%)", "DG CER num(%)", "DG WER num(%)",
        "AT CER raw(%)", "AT WER raw(%)", "AT CER num(%)", "AT WER num(%)",
    ]

    def round_row(d):
        return {k: (round(v, 2) if isinstance(v, float) else v) for k, v in d.items()}

    pooled_row = {
        "Contact": "POOLED (all calls)",
        "DG phrases": dg_phr_total,
        "AT phrases": at_phr_total,
        "DG CER raw(%)": _mean(pool_dg_cer_raw),
        "DG WER raw(%)": _mean(pool_dg_wer_raw),
        "DG CER num(%)": _mean(pool_dg_cer_num),
        "DG WER num(%)": _mean(pool_dg_wer_num),
        "AT CER raw(%)": _mean(pool_at_cer_raw),
        "AT WER raw(%)": _mean(pool_at_wer_raw),
        "AT CER num(%)": _mean(pool_at_cer_num),
        "AT WER num(%)": _mean(pool_at_wer_num),
    }
    with open(out_csv, "w", encoding="utf-8-sig", newline="") as f:
        wr = csv.DictWriter(f, fieldnames=fieldnames)
        wr.writeheader()
        for r in per_call_rows:
            wr.writerow(round_row(r))
        wr.writerow(round_row(pooled_row))
    print(f"\nWrote: {out_csv}")

    # ---- write XLSX (Per-Call + Pooled sheets) ----
    try:
        from openpyxl import Workbook
        from openpyxl.styles import Font
        wb = Workbook()
        ws = wb.active
        ws.title = "Per-Call"
        ws.append(fieldnames)
        for c in ws[1]:
            c.font = Font(bold=True)
        for r in per_call_rows:
            rr = round_row(r)
            ws.append([rr[k] if rr[k] is not None else "n/a" for k in fieldnames])
        # blank + pooled
        ws.append([])
        pr = round_row(pooled_row)
        prow = [pr[k] if pr[k] is not None else "n/a" for k in fieldnames]
        ws.append(prow)
        for c in ws[ws.max_row]:
            c.font = Font(bold=True)

        ws2 = wb.create_sheet("Pooled")
        ws2.append(["Metric", "Deepgram raw(%)", "Deepgram num-norm(%)",
                    "Transcribe raw(%)", "Transcribe num-norm(%)"])
        for c in ws2[1]:
            c.font = Font(bold=True)

        def r2(v):
            return round(v, 2) if v is not None else "n/a"

        ws2.append(["CER (macro, all phrases)", r2(_mean(pool_dg_cer_raw)), r2(_mean(pool_dg_cer_num)),
                    r2(_mean(pool_at_cer_raw)), r2(_mean(pool_at_cer_num))])
        ws2.append(["WER (macro, all phrases)", r2(_mean(pool_dg_wer_raw)), r2(_mean(pool_dg_wer_num)),
                    r2(_mean(pool_at_wer_raw)), r2(_mean(pool_at_wer_num))])
        ws2.append([])
        ws2.append(["Calls combined", len(calls)])
        ws2.append(["Deepgram phrases scored", dg_phr_total])
        ws2.append(["Transcribe phrases scored", at_phr_total])

        out_xlsx = args.out_prefix + ".xlsx"
        wb.save(out_xlsx)
        print(f"Wrote: {out_xlsx}")
    except ImportError:
        print("  (openpyxl not installed; CSV only)")


if __name__ == "__main__":
    main()
