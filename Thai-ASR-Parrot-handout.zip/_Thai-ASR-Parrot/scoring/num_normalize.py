#!/usr/bin/env python3
"""
num_normalize.py — Convert spoken number-words into digit strings so ASR
hypotheses that SPELL numbers out compare fairly against digit-based ground
truth.

For the Thai ASR test, callers and Deepgram render numbers in THAI
("แปด ศูนย์ หก ...", "ห้าพันบาท", "สองหมื่นห้าพัน"). Thai speakers say phone
numbers, money, and dates in Thai. This module normalizes THAI number-words
first, and also handles English number-words and bare digit runs so
"081-234-5678" and "0812345678" compare equal.

Two Thai-specific facts drive the design:
  1. Thai is written WITHOUT SPACES, so a spoken number is usually a single glued
     token (e.g. "ห้าพัน" = 5000, "สองหมื่นห้าพันสามร้อย" = 25300). This module
     therefore scans INSIDE each token for Thai numeral sub-strings, not just
     whole-token matches.
  2. Thai has extra magnitude units the Indo/Eng normalizers lack: หมื่น
     (10 000) and แสน (100 000), plus special forms ยี่ (=2, only before สิบ,
     giving ยี่สิบ=20) and เอ็ด (=1 in the ones place, e.g. สิบเอ็ด=11).

Applied identically to references AND hypotheses, so any systematic quirk
cancels out. It is a scoring aid, not a perfect NLU.

NOTE ON METRICS: because Thai has no word boundaries, WER is unreliable for Thai;
CER (character-level) is the primary metric. This normalizer maps number words
to digits so number-heavy phrases score on true recognition, not spelling.
"""

import re
import unicodedata

# --------------------------------------------------------------------------- #
# Thai number lexicon
# --------------------------------------------------------------------------- #
TH_DIGITS = {
    "ศูนย์": 0,
    "หนึ่ง": 1,
    "สอง": 2,
    "สาม": 3,
    "สี่": 4,
    "ห้า": 5,
    "หก": 6,
    "เจ็ด": 7,
    "แปด": 8,
    "เก้า": 9,
}
TH_EED = "เอ็ด"   # = 1 in the ones place (สิบเอ็ด=11, ยี่สิบเอ็ด=21)
TH_YEE = "ยี่"    # = 2, only before สิบ (ยี่สิบ = 20)
TH_UNITS = {
    "สิบ": 10,
    "ร้อย": 100,
    "พัน": 1_000,
    "หมื่น": 10_000,
    "แสน": 100_000,
    "ล้าน": 1_000_000,
}
# Thai (ๆ) digits sometimes appear as Thai numerals ๐๑๒๓๔๕๖๗๘๙
TH_NUMERALS = {ord(c): str(i) for i, c in enumerate("๐๑๒๓๔๕๖๗๘๙")}

# Longest tokens first, for greedy left-to-right matching inside a glued string.
_TH_TOKENS = sorted(
    list(TH_DIGITS) + list(TH_UNITS) + [TH_EED, TH_YEE],
    key=len, reverse=True,
)

# --------------------------------------------------------------------------- #
# English fallback lexicon (callers occasionally code-switch)
# --------------------------------------------------------------------------- #
EN_ONES = {
    "zero": 0, "oh": 0, "o": 0, "nought": 0,
    "one": 1, "two": 2, "three": 3, "four": 4, "five": 5,
    "six": 6, "seven": 7, "eight": 8, "nine": 9,
    "ten": 10, "eleven": 11, "twelve": 12, "thirteen": 13, "fourteen": 14,
    "fifteen": 15, "sixteen": 16, "seventeen": 17, "eighteen": 18, "nineteen": 19,
}
EN_TENS = {
    "twenty": 20, "thirty": 30, "forty": 40, "fourty": 40, "fifty": 50,
    "sixty": 60, "seventy": 70, "eighty": 80, "ninety": 90,
}
EN_SCALES = {"hundred": 100, "thousand": 1_000, "million": 1_000_000, "billion": 1_000_000_000}
MULT = {"double": 2, "triple": 3}
_EN_WORDS = set(EN_ONES) | set(EN_TENS) | set(EN_SCALES) | set(MULT) | {"and"}


def _norm(t):
    return unicodedata.normalize("NFC", t or "").lower()


# --------------------------------------------------------------------------- #
# Thai numeral parsing
# --------------------------------------------------------------------------- #
def _tokenize_thai_number(s):
    """Greedily split a glued Thai numeral string into number sub-tokens.
    Returns a list of tokens (digit words / unit words / ยี่ / เอ็ด) if the
    WHOLE string is Thai numerals, else None."""
    tokens = []
    i = 0
    n = len(s)
    while i < n:
        for tok in _TH_TOKENS:
            if s.startswith(tok, i):
                tokens.append(tok)
                i += len(tok)
                break
        else:
            return None  # contains a non-number Thai char -> not a pure number
    return tokens or None


def _parse_thai_tokens(tokens):
    """Parse a list of Thai number tokens -> int, using the standard Thai
    positional system. Handles ยี่สิบ (20), สิบเอ็ด (11), and the หมื่น/แสน/ล้าน
    units. ล้าน (million) acts as a big multiplier on everything accumulated so
    far."""
    total = 0        # committed by ล้าน groups
    section = 0      # value within the current ล้าน group
    current = 0      # the pending digit awaiting a unit
    prev_was_yee = False

    for t in tokens:
        if t in TH_DIGITS:
            current = TH_DIGITS[t]
        elif t == TH_YEE:            # ยี่ = 2 (only meaningful before สิบ)
            current = 2
            prev_was_yee = True
            continue
        elif t == TH_EED:            # เอ็ด = 1 in the ones place
            section += 1
            current = 0
        elif t == "สิบ":
            section += (current if current else 1) * 10
            current = 0
        elif t == "ร้อย":
            section += (current if current else 1) * 100
            current = 0
        elif t == "พัน":
            section += (current if current else 1) * 1_000
            current = 0
        elif t == "หมื่น":
            section += (current if current else 1) * 10_000
            current = 0
        elif t == "แสน":
            section += (current if current else 1) * 100_000
            current = 0
        elif t == "ล้าน":
            section = (section + current) if (section or current) else 1
            total += section * 1_000_000
            section = 0
            current = 0
        prev_was_yee = False

    return total + section + current


def _thai_number_run_to_digits(tokens):
    """Given Thai number tokens, decide digit-by-digit vs magnitude:
    - if any UNIT word (สิบ/ร้อย/พัน/หมื่น/แสน/ล้าน/ยี่/เอ็ด) present -> magnitude
    - else all bare digits (e.g. a phone number read digit by digit) -> concat"""
    has_unit = any(t in TH_UNITS or t in (TH_YEE, TH_EED) for t in tokens)
    if has_unit:
        return str(_parse_thai_tokens(tokens))
    # digit-by-digit
    return "".join(str(TH_DIGITS[t]) for t in tokens if t in TH_DIGITS)


def _match_thai_number_at(s, i):
    """Greedily match the longest run of Thai number sub-tokens starting at
    position i. Returns (tokens, end_index) or (None, i) if no number char
    starts here. Because Thai is unspaced, numbers are usually glued to prose;
    this lets us find a number embedded in a larger token."""
    tokens = []
    j = i
    n = len(s)
    while j < n:
        for tok in _TH_TOKENS:
            if s.startswith(tok, j):
                tokens.append(tok)
                j += len(tok)
                break
        else:
            break
    return (tokens if tokens else None), j


def _convert_thai_in_token(core):
    """Convert every Thai-numeral run embedded ANYWHERE in a (possibly unspaced,
    prose+number) token, leaving non-number Thai text intact. E.g.
    'โอนเงินสองล้านห้าแสนบาท' -> 'โอนเงิน2500000บาท'.
    Returns the rewritten string, or None if the token has no Thai number run."""
    out = []
    i = 0
    n = len(core)
    found = False
    while i < n:
        toks, j = _match_thai_number_at(core, i)
        if toks:
            out.append(_thai_number_run_to_digits(toks))
            found = True
            i = j
        else:
            out.append(core[i])
            i += 1
    return "".join(out) if found else None


# --------------------------------------------------------------------------- #
# English fallback parsing
# --------------------------------------------------------------------------- #
def _en_has_scale(tokens):
    return any(t in EN_SCALES for t in tokens)


def _parse_en_magnitude(tokens):
    total = 0
    current = 0
    for t in tokens:
        if t in EN_ONES:
            current += EN_ONES[t]
        elif t in EN_TENS:
            current += EN_TENS[t]
        elif t == "hundred":
            current = (current or 1) * 100
        elif t in ("thousand", "million", "billion"):
            total += (current or 1) * EN_SCALES[t]
            current = 0
        elif t == "and":
            continue
    return total + current


def _en_token_digit(tok):
    if tok in EN_ONES and EN_ONES[tok] < 10:
        return str(EN_ONES[tok])
    return ""


# --------------------------------------------------------------------------- #
# Main
# --------------------------------------------------------------------------- #
def convert(text: str) -> str:
    t = _norm(text)
    # Thai is written WITHOUT spaces, but Deepgram often inserts spurious spaces
    # INSIDE Thai words/numbers (e.g. "ศ ูน แป ด" for "ศูนย์แปด"). Those spaces
    # are noise that would stop the number tokenizer from recognizing a glued
    # Thai numeral. Collapse any whitespace that sits BETWEEN two Thai
    # characters, so Thai number words become contiguous again. ASCII<->Thai and
    # ASCII<->ASCII gaps are left intact (English words / digit groups stay
    # separated).
    t = re.sub(r"(?<=[\u0e00-\u0e7f])\s+(?=[\u0e00-\u0e7f])", "", t)
    # normalize currency/symbol noise
    t = (t.replace("฿", " ").replace("บาท", " ").replace("baht", " ")
           .replace("thb", " ").replace("rp", " ").replace("rupiah", " "))
    # convert any Thai numeral glyphs (๐-๙) to ASCII digits up front
    t = t.translate(TH_NUMERALS)

    raw = re.split(r"\s+", t)
    tokens = [x for x in raw if x != ""]

    def core_of(tok):
        return tok.strip(".,;:!?()[]{}\"'`-/")

    out = []
    i = 0
    n = len(tokens)
    while i < n:
        core = core_of(tokens[i])

        # 1) Thai numerals — standalone ("ห้าพัน"), or embedded in unspaced prose
        #    ("โอนเงินสองล้านห้าแสนบาท" -> "โอนเงิน2500000บาท"). Thai has no word
        #    spaces, so numbers are usually glued to surrounding text.
        if any(ch in core for ch in "ศูนย์หนึ่งสองสามสี่ห้าหกเจ็ดแปดเก้าสิบร้อยพันหมื่นแสนล้านเอ็ดยี่"):
            converted = _convert_thai_in_token(core)
            if converted is not None:
                out.append(converted)
                i += 1
                continue

        # 2) A bare digit run (strip separators): "081-234-5678" -> "0812345678"
        if re.search(r"\d", core):
            out.append(re.sub(r"[.\-,_ ]", "", core))
            i += 1
            continue

        # 3) An English number run (space-separated words).
        if core in _EN_WORDS and core != "and":
            j = i
            run = []
            while j < n:
                c = core_of(tokens[j])
                if c in _EN_WORDS and c != "and":
                    run.append(c); j += 1
                elif re.search(r"\d", c):
                    run.append(re.sub(r"[.\-,_ ]", "", c)); j += 1
                else:
                    break
            if _en_has_scale(run):
                out.append(str(_parse_en_magnitude(run)))
            else:
                digits = []
                k = 0
                while k < len(run):
                    ck = run[k]
                    if ck in MULT and k + 1 < len(run):
                        nxt = _en_token_digit(run[k + 1])
                        if len(nxt) == 1:
                            digits.append(nxt * MULT[ck]); k += 2; continue
                    if ck.isdigit():
                        digits.append(ck)
                    else:
                        digits.append(_en_token_digit(ck))
                    k += 1
                out.append("".join(digits))
            i = j
            continue

        # 4) Not a number -> pass through unchanged.
        out.append(tokens[i])
        i += 1

    return re.sub(r"\s+", " ", " ".join(out)).strip()


if __name__ == "__main__":
    tests = [
        # Thai digit-by-digit phone numbers (glued and spaced)
        ("ศูนย์แปดหนึ่งสองสามสี่ห้าหกเจ็ดแปด", "0812345678"),
        # Spaces between Thai chars are collapsed first (Deepgram inserts spurious
        # intra-word spaces), so spaced Thai digits rejoin and convert correctly.
        ("ศูนย์ แปด หนึ่ง สอง สาม สี่ ห้า หก เจ็ด แปด", "0812345678"),
        ("081-234-5678", "0812345678"),
        # Thai magnitudes / money
        ("ห้าพัน", "5000"),
        ("หนึ่งร้อยห้าสิบ", "150"),
        ("สองหมื่นห้าพัน", "25000"),
        ("หนึ่งแสนห้าหมื่น", "150000"),
        ("สิบเอ็ด", "11"),
        ("ยี่สิบ", "20"),
        ("ยี่สิบเอ็ด", "21"),
        ("หนึ่งล้าน", "1000000"),
        ("สองล้านห้าแสน", "2500000"),
        ("สิบ", "10"),
        # Thai numeral glyphs
        ("๐๘๑๒๓๔๕๖๗๘", "0812345678"),
        # English fallback
        ("one hundred thousand", "100000"),
        ("double seven eight", "778"),
        # prose must NOT be mangled
        ("สวัสดีครับ", "สวัสดีครับ"),
        ("ขอบคุณมากครับ", "ขอบคุณมากครับ"),
    ]
    for src, exp in tests:
        got = convert(src)
        print(f"[{'OK ' if got==exp else 'DIFF'}] {src!r} -> {got!r}" + ("" if got==exp else f"  exp {exp!r}"))
