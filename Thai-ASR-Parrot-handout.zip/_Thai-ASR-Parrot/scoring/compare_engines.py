#!/usr/bin/env python3
"""
compare_engines.py — Side-by-side ASR accuracy: Deepgram vs Amazon Transcribe,
scored against the SAME Thai reference phrases.

Why this exists
---------------
Amazon Connect Agentic Voice uses DEEPGRAM as the live STT. The Deepgram output
is captured automatically in the Q-in-Connect (wisdom) CloudWatch transcript log
(each CUSTOMER turn == a Deepgram hypothesis) -- no Lambda/DynamoDB needed.
Contact Lens independently re-transcribes the same call audio with AMAZON
TRANSCRIBE. They are two different engines on the same audio. This tool scores
both against your reference list so you can compare them fairly.

  reference (ground truth)
        (Deepgram)          from wisdom CloudWatch log, --deepgram-cloudwatch
        (Amazon Transcribe) from Contact Lens: --transcribe-api or --transcribe-json
        -> per-phrase + aggregate CER/WER for EACH engine, side by side

Both sources are ordered-by-turn (no explicit per-phrase sequence), so
positional alignment is used by default.

Reuses wer_cer.py for loaders, metrics, normalization, and alignment.

Usage
-----
  # Deepgram from CloudWatch, Amazon Transcribe via Connect realtime analysis API
  python compare_engines.py \
      --refs-csv ../references/references.csv \
      --deepgram-cloudwatch /aws/wisdom/assistant/<ASSISTANT_ID> \
      --contact-id <CID> \
      --transcribe-api --instance-id <INSTANCE_ID> --region <REGION> \
      --out-prefix results/Thai-CER-WER_<CID>

  # Amazon Transcribe from a Contact Lens transcript JSON instead of the API
  python compare_engines.py \
      --refs-csv ../references/references.csv \
      --deepgram-cloudwatch /aws/wisdom/assistant/<ASSISTANT_ID> --contact-id <CID> \
      --transcribe-json contactlens_transcript.json \
      --out-prefix results/Thai-CER-WER_<CID>
"""

import argparse
import csv
import os
import sys

import wer_cer as w  # reuse everything


def load_transcribe_from_api(instance_id: str, contact_id: str, region: str) -> list[dict]:
    """Pull caller turns (Amazon Transcribe hypotheses) from Contact Lens via
    the Connect realtime contact analysis API."""
    try:
        import boto3
    except ImportError:
        sys.exit("boto3 required for --transcribe-api:  pip install boto3")
    client = boto3.client("connect", region_name=region)
    records = []
    seq = 0
    next_token = None
    from botocore.exceptions import ClientError
    while True:
        kwargs = dict(
            InstanceId=instance_id,
            ContactId=contact_id,
            OutputType="Raw",
            SegmentTypes=["Transcript"],
            MaxResults=100,
        )
        if next_token:
            kwargs["NextToken"] = next_token
        try:
            resp = client.list_realtime_contact_analysis_segments_v2(**kwargs)
        except ClientError as exc:
            code = exc.response.get("Error", {}).get("Code", "")
            print(f"  Amazon Transcribe (Contact Lens) unavailable for this contact: {code}.")
            print("  (Contact Lens analysis may not have run on this call, or has expired.)")
            print("  Proceeding with Deepgram-only results.")
            return []
        for seg in resp.get("Segments", []):
            tr = seg.get("Transcript")
            if not tr:
                continue
            role = (tr.get("ParticipantRole") or "").upper()
            content = tr.get("Content") or ""
            if "CUSTOMER" in role and content.strip() and not w.is_junk_turn(content):
                seq += 1
                records.append(w._hyp_record(seq, content.strip(), contact_id, str(tr.get("BeginOffsetMillis", ""))))
        next_token = resp.get("NextToken")
        if not next_token:
            break
    return records


def score_engine(refs, hyps, align_mode):
    pairs = w.align(refs, hyps, align_mode)
    scored = w.score_pairs(pairs)
    agg = w.aggregate(scored)
    return scored, agg


def main():
    ap = argparse.ArgumentParser(description="Compare Deepgram vs Amazon Transcribe WER/CER on the same Thai references.")
    # references
    gref = ap.add_mutually_exclusive_group(required=True)
    gref.add_argument("--refs-csv")
    gref.add_argument("--refs-xlsx")
    gref.add_argument("--refs-txt")
    # deepgram source
    ap.add_argument("--deepgram-cloudwatch", metavar="LOG_GROUP",
                    help="Q-in-Connect wisdom CloudWatch log group (e.g. /aws/wisdom/assistant/<id>); CUSTOMER turns = Deepgram hypotheses")
    ap.add_argument("--cw-stream", default="QiCAssistantTranscript", help="CloudWatch stream name")
    ap.add_argument("--deepgram-jsonl", help="Alternatively, Deepgram hypotheses from JSONL / S3 dir")
    # amazon transcribe source (contact lens)
    ap.add_argument("--transcribe-api", action="store_true", help="Pull Amazon Transcribe turns from Connect realtime analysis API")
    ap.add_argument("--transcribe-json", help="Contact Lens transcript JSON (Amazon Transcribe)")
    # shared
    ap.add_argument("--contact-id", help="Connect contactId (for DDB filter and the Transcribe API)")
    ap.add_argument("--instance-id", help="Connect instanceId (for --transcribe-api)")
    ap.add_argument("--region", default="ap-southeast-1")
    ap.add_argument("--align", choices=["sequence", "order", "best-match"], default="best-match",
                    help="Alignment (default: best-match — content-based two-pass, resilient to dropped/mis-ordered/garbled phrases; each engine is aligned to the references independently)")
    ap.add_argument("--out-prefix", default="compare_results")
    args = ap.parse_args()

    if getattr(w, "_vnnum", None) is None:
        print("NOTE: num_normalize.py not found; number-normalized columns will equal raw columns.")

    # references
    if args.refs_csv:
        refs = w.load_refs_csv(args.refs_csv)
    elif args.refs_xlsx:
        refs = w.load_refs_xlsx(args.refs_xlsx)
    else:
        refs = w.load_refs_txt(args.refs_txt)
    if not refs:
        sys.exit("No references loaded.")

    # deepgram hyps
    if args.deepgram_cloudwatch:
        dg = w.load_hyps_cloudwatch(args.deepgram_cloudwatch, args.region, args.contact_id, args.cw_stream)
    elif args.deepgram_jsonl:
        dg = w.load_hyps_jsonl(args.deepgram_jsonl)
    else:
        sys.exit("Provide a Deepgram source: --deepgram-cloudwatch or --deepgram-jsonl")

    # amazon transcribe hyps
    if args.transcribe_api:
        if not (args.instance_id and args.contact_id):
            sys.exit("--transcribe-api needs --instance-id and --contact-id")
        at = load_transcribe_from_api(args.instance_id, args.contact_id, args.region)
    elif args.transcribe_json:
        at = w.load_hyps_contactlens(args.transcribe_json)
    else:
        at = []
        print("WARNING: no Amazon Transcribe source given; comparison will show Deepgram only.")

    print(f"References: {len(refs)} | Deepgram turns: {len(dg)} | Amazon Transcribe turns: {len(at)}")
    print(f"Metrics engine: {w.METRICS_SOURCE}\n")

    # Score each engine TWICE: once RAW (numbers as written) and once with
    # Thai spoken-numbers converted to digits (fair recognition). We fix
    # alignment on the RAW pass and reuse the same pairs for both, so the two
    # views differ only in number handling, not in which hypothesis matched.
    def score_both(refs, hyps):
        if not hyps:
            return [], None, [], None
        pairs = w.align(refs, hyps, args.align)
        w.NUMBER_MODE = "off"
        raw = w.score_pairs(pairs)
        # Aggregates reflect ONLY phrases that were actually spoken/captured.
        # References the tester did not read produce an empty hypothesis (100%
        # error) and would otherwise distort the corpus average — exclude them.
        raw_agg = w.aggregate([s for s in raw if s.matched])
        if getattr(w, "_vnnum", None) is not None:
            w.NUMBER_MODE = "words2digits"
            num = w.score_pairs(pairs)
            num_agg = w.aggregate([s for s in num if s.matched])
            w.NUMBER_MODE = "off"
        else:
            num, num_agg = raw, raw_agg
        return raw, raw_agg, num, num_agg

    dg_raw, dg_raw_agg, dg_num, dg_num_agg = score_both(refs, dg)
    at_raw, at_raw_agg, at_num, at_num_agg = score_both(refs, at)

    # index by sequence
    at_raw_by = {s.pair.sequence: s for s in at_raw}
    dg_num_by = {s.pair.sequence: s for s in dg_num}
    at_num_by = {s.pair.sequence: s for s in at_num}

    out_csv = args.out_prefix + ".csv"
    os.makedirs(os.path.dirname(out_csv) or ".", exist_ok=True)
    header = [
        "Sequence", "GroundTruth",
        # Deepgram
        "Deepgram ASR",
        "DG CER raw(%)", "DG WER raw(%)",
        "DG CER num-normalized(%)", "DG WER num-normalized(%)",
        "DG Captured?",
        # Amazon Transcribe
        "Transcribe ASR",
        "AT CER raw(%)", "AT WER raw(%)",
        "AT CER num-normalized(%)", "AT WER num-normalized(%)",
        "AT Captured?",
    ]
    with open(out_csv, "w", encoding="utf-8-sig", newline="") as f:
        wr = csv.writer(f)
        wr.writerow(header)
        for s in dg_raw:
            seq = s.pair.sequence
            dn = dg_num_by.get(seq)
            a = at_raw_by.get(seq)
            an = at_num_by.get(seq)
            wr.writerow([
                seq, s.pair.reference,
                s.pair.hypothesis,
                w.pct(s.cer), w.pct(s.wer),
                (w.pct(dn.cer) if dn else ""), (w.pct(dn.wer) if dn else ""),
                ("yes" if s.matched else "MISSING"),
                (a.pair.hypothesis if a else ""),
                (w.pct(a.cer) if a else ""), (w.pct(a.wer) if a else ""),
                (w.pct(an.cer) if an else ""), (w.pct(an.wer) if an else ""),
                ("yes" if (a and a.matched) else "MISSING") if at else "n/a",
            ])

    # how many phrases were actually spoken/captured (used for the aggregates)
    dg_counted = sum(1 for s in dg_raw if s.matched)
    at_counted = sum(1 for s in at_raw if s.matched) if at else 0

    # console comparison table (raw vs number-normalized, both engines)
    print("=" * 84)
    print("  ASR ENGINE COMPARISON — Deepgram vs Amazon Transcribe (Thai)")
    print("=" * 84)
    print(f"  Phrases scored (spoken/captured only): Deepgram {dg_counted}/{len(refs)}"
          + (f" | Amazon Transcribe {at_counted}/{len(refs)}" if at else "")
          + f"  ({len(refs) - dg_counted} unread reference phrases excluded from averages)")
    print("  " + "-" * 82)
    print(f"  {'Metric':<26}{'Deepgram raw':>14}{'DG num-norm':>14}{'Transcribe raw':>16}{'AT num-norm':>14}")
    print("  " + "-" * 82)

    def q(agg, key):
        return agg[key] if agg else None

    def cell(v):
        return w.pct(v) if v is not None else "n/a"

    def row(label, dgr, dgn, atr, atn):
        print(f"  {label:<26}{cell(dgr):>14}{cell(dgn):>14}{cell(atr):>16}{cell(atn):>14}")

    row("CER macro (per phrase)", q(dg_raw_agg,"macro_cer"), q(dg_num_agg,"macro_cer"),
        q(at_raw_agg,"macro_cer"), q(at_num_agg,"macro_cer"))
    row("CER micro (corpus)", q(dg_raw_agg,"micro_cer"), q(dg_num_agg,"micro_cer"),
        q(at_raw_agg,"micro_cer"), q(at_num_agg,"micro_cer"))
    row("WER macro", q(dg_raw_agg,"macro_wer"), q(dg_num_agg,"macro_wer"),
        q(at_raw_agg,"macro_wer"), q(at_num_agg,"macro_wer"))
    print("=" * 84)
    print("  raw = numbers as each engine wrote them (Deepgram spells them out).")
    print("  num-norm = Thai spoken numbers converted to digits on both sides")
    print("             → reflects TRUE recognition, not number formatting.")
    print("  Averages cover only phrases the tester actually read; unread")
    print("  reference phrases are shown in the CSV but excluded from the summary.")
    print("  Lower is better. Deepgram is the live Agentic Voice engine; Amazon")
    print("  Transcribe is Contact Lens's separate re-transcription of the same audio.")
    print(f"\nWrote: {out_csv}")

    # xlsx: same per-phrase columns + a summary sheet
    try:
        from openpyxl import Workbook
        wb = Workbook()
        ws = wb.active
        ws.title = "Side-by-Side"
        ws.append(header)
        for s in dg_raw:
            seq = s.pair.sequence
            dn = dg_num_by.get(seq); a = at_raw_by.get(seq); an = at_num_by.get(seq)
            ws.append([
                seq, s.pair.reference,
                s.pair.hypothesis,
                round(s.cer*100,2), round(s.wer*100,2),
                (round(dn.cer*100,2) if dn else ""), (round(dn.wer*100,2) if dn else ""),
                ("yes" if s.matched else "MISSING"),
                (a.pair.hypothesis if a else ""),
                (round(a.cer*100,2) if a else ""), (round(a.wer*100,2) if a else ""),
                (round(an.cer*100,2) if an else ""), (round(an.wer*100,2) if an else ""),
                ("yes" if (a and a.matched) else "MISSING") if at else "n/a",
            ])
        ws2 = wb.create_sheet("Summary")
        ws2.append(["Metric", "Deepgram raw(%)", "Deepgram num-norm(%)",
                    "Transcribe raw(%)", "Transcribe num-norm(%)"])
        def s2(label, key):
            ws2.append([label,
                        (round(q(dg_raw_agg,key)*100,2) if dg_raw_agg else "n/a"),
                        (round(q(dg_num_agg,key)*100,2) if dg_num_agg else "n/a"),
                        (round(q(at_raw_agg,key)*100,2) if at_raw_agg else "n/a"),
                        (round(q(at_num_agg,key)*100,2) if at_num_agg else "n/a")])
        s2("CER macro", "macro_cer")
        s2("CER micro", "micro_cer")
        s2("WER macro", "macro_wer")
        out_xlsx = args.out_prefix + ".xlsx"
        wb.save(out_xlsx)
        print(f"Wrote: {out_xlsx}")
    except ImportError:
        print("  (openpyxl not installed; CSV only)")


if __name__ == "__main__":
    main()
