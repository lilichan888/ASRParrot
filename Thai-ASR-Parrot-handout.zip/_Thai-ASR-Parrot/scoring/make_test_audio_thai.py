#!/usr/bin/env python3
"""
make_test_audio_thai.py — Generate WAV files for the first N Thai reference
phrases using Cartesia, for a parrot ASR smoke test.

OPTIONAL. The real parrot test measures DEEPGRAM ASR accuracy on a LIVE human
call. These generated WAVs are just independent test *input* (a different vendor
from the ASR under test) so you can dry-run the pipeline without a human reader.
A real human call is still the true proof.

NOTE: macOS also ships a free Thai voice ("Kanya", th_TH). For a no-cost smoke
test you can skip Cartesia entirely and use:
    say -v Kanya -o out.aiff "ภาษาไทย..." && afconvert out.aiff out.wav -f WAVE -d LEI16 -c 1

Reads phrases from references.csv (reference column) or the xlsx GroundTruth
column via wer_cer's loaders.
"""
import argparse
import os
import sys

import wer_cer as w


def main():
    ap = argparse.ArgumentParser()
    src = ap.add_mutually_exclusive_group(required=True)
    src.add_argument("--refs-csv")
    src.add_argument("--refs-xlsx")
    ap.add_argument("--count", type=int, default=5)
    ap.add_argument("--out-dir", default="../test_audio")
    ap.add_argument("--voice-id", required=True,
                    help="Cartesia voice id for a Thai (th) voice")
    ap.add_argument("--model-id", default="sonic-3.5")
    ap.add_argument("--env-file", required=True,
                    help="File containing CARTESIA_API_KEY=...")
    args = ap.parse_args()

    key = None
    for line in open(args.env_file, encoding="utf-8"):
        if line.startswith("CARTESIA_API_KEY"):
            key = line.split("=", 1)[1].strip().strip('"').strip("'")
            break
    if not key:
        sys.exit("No CARTESIA_API_KEY in env file")

    if args.refs_csv:
        refs = w.load_refs_csv(args.refs_csv)[:args.count]
    else:
        refs = w.load_refs_xlsx(args.refs_xlsx)[:args.count]
    os.makedirs(args.out_dir, exist_ok=True)
    from cartesia import Cartesia
    client = Cartesia(api_key=key)

    print(f"Generating {len(refs)} WAVs with Cartesia voice {args.voice_id} (Thai, model {args.model_id})...")
    for seq, phrase, *_ in refs:
        out = os.path.join(args.out_dir, f"phrase_{seq:02d}.wav")
        print(f"  [{seq}] {phrase[:60]}")
        try:
            audio = client.tts.bytes(
                model_id=args.model_id,
                transcript=phrase,
                voice={"mode": "id", "id": args.voice_id},
                language="th",
                output_format={"container": "wav", "encoding": "pcm_s16le", "sample_rate": 44100},
            )
            with open(out, "wb") as f:
                f.write(b"".join(audio))
            print(f"       -> {out}")
        except Exception as e:
            print(f"       FAILED: {e}")

    idx = os.path.join(args.out_dir, "index.txt")
    with open(idx, "w", encoding="utf-8") as f:
        for seq, phrase, *_ in refs:
            f.write(f"phrase_{seq:02d}.wav\t{phrase}\n")
    print(f"Index: {idx}")


if __name__ == "__main__":
    main()
