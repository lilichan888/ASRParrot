# Indonesia ASR Parrot — ASR Test for Amazon Connect Agentic Voice

A "parrot" ASR-accuracy test for **Bahasa Indonesia (id-ID)**, mirroring the
proven GCash Tagalog parrot. A human tester reads Indonesian phrases from a
fixed list; Connect Agentic Voice does STT (Deepgram) and TTS. The agent does
**not** repeat the phrase back and calls **no tool** — it just paces the tester
with the cue *"Silakan bicara"*. The Deepgram transcript is captured
automatically from CloudWatch, then scored against the known phrases to produce
CER / WER.

> **New here? Start with [`TRAINING_GUIDE.md`](TRAINING_GUIDE.md)** — a
> beginner, click-by-click walkthrough. This README is the shorter technical
> reference.

---

## How it works

```
Tester reads an Indonesian phrase   (= REFERENCE, from references/)
      │  speech
      ▼
Amazon Connect Agentic Voice
   • Deepgram  → speech-to-text  (= HYPOTHESIS)
   • Agent "Beo" → says only "Silakan bicara" (no parrot, no tool)
      │
      ▼
Deepgram hypothesis auto-logged to CloudWatch:
   /aws/wisdom/assistant/<assistantId>  (each CUSTOMER turn = a hypothesis)
      │
      ▼
scoring/wer_cer.py       → CER/WER vs references (best-match alignment)
scoring/compare_engines.py → Deepgram vs Amazon Transcribe (Contact Lens)
scoring/rollup.py        → combine multiple testers' calls
```

No Lambda, DynamoDB, or logging tool — Deepgram output is read straight from the
Q-in-Connect (wisdom) CloudWatch transcript log. Contact Lens (Amazon
Transcribe) runs in parallel on the same audio for the optional engine
comparison.

---

## Repository layout

```
_Indonesia-ASR-Parrot/
├── README.md                              ← this file
├── TRAINING_GUIDE.md                      ← step-by-step guide for colleagues
├── references/
│   ├── references.csv                     ← 21 Indonesian phrases (sequence, reference, intent)
│   └── references.txt                     ← same phrases, one per line
├── agent/
│   └── Indonesia_Parrot_Prompt.txt        ← AI agent system prompt ("Beo")
├── connect/
│   └── Indonesia_Parrot_Flow.json         ← contact flow (has REPLACE_WITH_* placeholders)
└── scoring/
    ├── wer_cer.py                         ← Deepgram CER/WER scoring
    ├── compare_engines.py                 ← Deepgram vs Amazon Transcribe
    ├── rollup.py                          ← combine multiple calls into one summary
    ├── num_normalize.py                   ← INDONESIAN number-word → digit normalizer
    ├── make_test_audio_indonesia.py       ← (optional) Cartesia audio for dry-runs
    ├── requirements.txt
    └── results/                           ← output CSV/XLSX land here
```

---

## Language facts (verified)

- Bahasa Indonesia **is supported** by Amazon Connect Agentic Voice / AI agents.
  Source: <https://docs.aws.amazon.com/connect/latest/adminguide/supported-languages.html>
  (`id_ID` is listed; part of the March 2026 expansion to more Agentic Voice
  languages).
- Docs language code: `id_ID`. In the **contact flow** use the hyphenated form
  **`id-ID`** (both `AnalyticsLanguage` and the `Set language` block).
- **Numbers are spoken in INDONESIAN** by Indonesian callers ("nol delapan satu
  dua...", "seratus lima puluh ribu rupiah", "tujuh belas Agustus"). This is the
  key difference from the Tagalog test, where Filipinos say numbers in English.
  `num_normalize.py` therefore normalizes Indonesian number words (with English
  as a fallback).

Indonesian numbers the normalizer handles: `nol`/`kosong` (0), `satu`–`sembilan`
(1–9), `sepuluh` (10), `sebelas` (11), `<n> belas` (teens), `<n> puluh` (tens),
`ratus` (100), `ribu` (1 000), `juta` (1 000 000), `miliar`/`milyar`
(1 000 000 000), and the `se-` contractions `seratus` / `seribu` / `sepuluh`.

---

## Deployment (summary)

Full click-by-click steps are in **TRAINING_GUIDE.md**. In brief:

1. **AI agent (console)** — create `Indonesia-ASR-Parrot`, paste
   `agent/Indonesia_Parrot_Prompt.txt`, language **id-ID**, publish. Copy the
   **Wisdom Assistant ARN** and **AI agent version ARN**.
2. **Voice + Lex (console)** — from a *Set voice* block (Agentic Voice →
   Indonesian) note the **voice name**; copy your **Lex bot alias ARN** (a bot
   with an `id_ID` locale).
3. **Fill placeholders** in `connect/Indonesia_Parrot_Flow.json`:

   | Placeholder | Value |
   |---|---|
   | `REPLACE_WITH_WISDOM_ASSISTANT_ARN` | Wisdom Assistant ARN |
   | `REPLACE_WITH_AI_AGENT_ARN` | AI agent version ARN (appears twice) |
   | `REPLACE_WITH_LEX_BOT_ALIAS_ARN` | Lex bot alias ARN |
   | `REPLACE_WITH_INDONESIAN_AGENTIC_VOICE` | Indonesian voice name |

   Then create + publish the flow:
   ```bash
   export AWS_PROFILE=<profile>
   aws connect create-contact-flow --region <region> \
     --instance-id <instance-id> \
     --name "Indonesia-ASR-Parrot-Flow" --type CONTACT_FLOW \
     --content file://connect/Indonesia_Parrot_Flow.json
   ```
4. **Phone number** — attach a spare/claimed number to the flow.
5. **CloudWatch** — confirm the wisdom transcript log group
   `/aws/wisdom/assistant/<assistantId>` exists (enable log delivery if not).

---

## Run a test call

1. Tester calls the hotline number.
2. Hears *"Silakan mulai bicara"* (flow greeting).
3. Reads phrase 1 → agent says *"Silakan bicara"* → reads phrase 2 → and so on.
   Speak one phrase, pause clearly, wait for the cue.
4. Note the **contactId** (Console → Contact search).

Brief the tester: **speak numbers naturally in Indonesian** — the scoring
handles that.

---

## Scoring

Setup (once):
```bash
cd scoring
python3 -m venv .venv && ./.venv/bin/pip install -r requirements.txt
```

### Deepgram CER/WER
```bash
./.venv/bin/python wer_cer.py \
  --refs-csv ../references/references.csv \
  --hyps-cloudwatch /aws/wisdom/assistant/<ASSISTANT-ID> \
  --contact-id <CID> --region <region> \
  --align best-match \
  --number-mode words2digits \
  --out-prefix results/Indonesia-CER-WER_<CID>
```

### Deepgram vs Amazon Transcribe (Contact Lens)
Download the Contact Lens analysis JSON from the instance's S3 bucket
(`Analysis/Voice/.../<contactId>_analysis_*.json`), then:
```bash
./.venv/bin/python compare_engines.py \
  --refs-csv ../references/references.csv \
  --deepgram-cloudwatch /aws/wisdom/assistant/<ASSISTANT-ID> --contact-id <CID> \
  --transcribe-json <path-to-analysis.json> \
  --region <region> \
  --out-prefix results/Indonesia-CER-WER_<CID>
```

### Combine several calls
```bash
./.venv/bin/python rollup.py       # globs results/Indonesia-CER-WER_*.csv
```

### Reading results
- Indonesian callers say numbers in **Indonesian**, so Deepgram may output words
  or digits. `--number-mode words2digits` converts Indonesian number-words →
  digits on BOTH sides via `num_normalize.py`, so a spelled-out number and a
  typed number compare equal.
- Use the **number-normalized** CER/WER columns for true recognition accuracy.
- `--align best-match` handles dropped/mis-ordered/garbled phrases.
- Eyeball the per-utterance CSV: `Captured? = MISSING` = phrase not spoken or
  not confidently placed. A per-call CER far above 100% means mis-alignment
  (skipped phrases, or a conversation instead of a script read) — redo it.

---

## Validation status

The scoring pipeline is locally validated: with the 21-phrase reference list and
a mock Deepgram-style hypothesis set, `wer_cer.py --number-mode words2digits`
produced ~2.9% raw CER and **0.00%** number-normalized CER, confirming the
Indonesian number normalizer correctly equates spelled-out and typed numbers.
`num_normalize.py` passes all its built-in self-tests (`python3 num_normalize.py`).

A **real call** on the created agent is the true proof of end-to-end behavior —
build the agent/flow/number per the guide and place one test call.

---

## Honest caveats

- **Indonesian voice name is read from the console dropdown** (Set voice →
  Agentic Voice → Indonesian); it is not in the docs, so the flow uses a
  placeholder you must fill.
- `num_normalize.py` covers standard Indonesian numerals and the common `se-`
  contractions plus English fallback. If Deepgram emits an unusual spelling,
  sanity-check number-heavy rows after the first real call and extend the
  lexicon if needed.
- **Best-match alignment** can mark a badly-garbled phrase MISSING if few turns
  are captured. Clean 1:1 turns (clear pauses) give the most trustworthy numbers.
- **Live-call telephony / Agentic Voice usage costs apply** for connected
  minutes.
