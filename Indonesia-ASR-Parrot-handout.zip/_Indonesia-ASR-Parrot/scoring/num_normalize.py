#!/usr/bin/env python3
"""
num_normalize.py — Convert spoken number-words into digit strings so ASR
hypotheses that SPELL numbers out compare fairly against digit-based ground
truth.

For the Bahasa Indonesia ASR test, callers and Deepgram render numbers in
INDONESIAN ("nol delapan satu dua...", "seratus ribu rupiah", "dua puluh lima").
Indonesian speakers say phone numbers, money, and dates in Indonesian (unlike
Filipino callers, who use English). This module therefore normalizes INDONESIAN
number-words first, and also handles English number-words and bare digit runs so
"0812-3456-7890" and "08123456789" compare equal.

Applied identically to references AND hypotheses, so any systematic quirk
cancels out. It is a scoring aid, not a perfect NLU.

Handles:
  - digit-by-digit:  "nol delapan satu dua tiga" -> "08123"
    (also "kosong"/"nol" -> 0)
  - magnitude:       "seratus ribu" -> "100000"
                     "dua juta lima ratus ribu" -> "2500000"
                     "dua puluh lima" -> "25"; "seribu" -> "1000"
  - English fallback: "one hundred thousand" -> "100000"; "double seven" -> "77"
  - existing digits: "0812-3456-7890" -> "08123456789"; "100.000" -> "100000"

Indonesian grammar covered:
  satu..sembilan (1-9); nol/kosong (0)
  sepuluh (10), sebelas (11), <n> belas (12-19)
  <n> puluh (tens: 20,30,...); se... contracts to "one" (seratus, seribu, sepuluh)
  ratus (100), ribu (1 000), juta (1 000 000), miliar/milyar (1 000 000 000)
"""

import re
import unicodedata

# --------------------------------------------------------------------------- #
# Indonesian number lexicon
# --------------------------------------------------------------------------- #
ID_ONES = {
    "nol": 0, "kosong": 0,
    "satu": 1, "dua": 2, "tiga": 3, "empat": 4, "lima": 5,
    "enam": 6, "tujuh": 7, "delapan": 8, "sembilan": 9,
}
# "se" is the bound form of "satu" used before puluh/ratus/ribu/belas.
ID_SE = "se"
ID_TEEN_WORD = "belas"      # <n> belas => 10 + n ; "sebelas" => 11
ID_SCALES = {
    "puluh": 10,
    "ratus": 100,
    "ribu": 1_000,
    "juta": 1_000_000,
    "miliar": 1_000_000_000,
    "milyar": 1_000_000_000,
}
ID_SEPULUH = "sepuluh"      # 10

# --------------------------------------------------------------------------- #
# English number lexicon (fallback; Indonesian callers occasionally code-switch)
# --------------------------------------------------------------------------- #
EN_ONES = {
    "zero": 0, "oh": 0, "o": 0, "nought": 0,
    "one": 1, "two": 2, "three": 3, "four": 4, "five": 5,
    "six": 6, "seven": 7, "eight": 8, "nine": 9,
    "ten": 10, "eleven": 11, "twelve": 12, "thirteen": 13, "fourteen": 14,
    "fifteen": 15, "sixteen": 16, "seventeen": 17, "eighteen": 18, "nineteen": 19,
}
EN_TENS = {
    "twenty": 20, "thirty": 30, "forty": 40, "fourty": 40, "fifty": 50,
    "sixty": 60, "seventy": 70, "eighty": 80, "ninety": 90,
}
EN_SCALES = {"hundred": 100, "thousand": 1_000, "million": 1_000_000, "billion": 1_000_000_000}
MULT = {"double": 2, "triple": 3, "ganda": 2}  # "ganda" ~ double (rare)

# "se"-prefixed contractions expand to "satu <scale>" so the parser handles them
# uniformly. sepuluh -> satu puluh (=10), seratus -> satu ratus, seribu -> satu
# ribu, sebelas -> satu belas (=11), sejuta -> satu juta.
ID_SE_FORMS = {
    "sepuluh": ("satu", "puluh"),
    "seratus": ("satu", "ratus"),
    "seribu": ("satu", "ribu"),
    "sejuta": ("satu", "juta"),
    "sebelas": ("satu", "belas"),
}

# All recognised number words (used to detect a number run)
_ID_WORDS = set(ID_ONES) | set(ID_SCALES) | set(ID_SE_FORMS) | {ID_TEEN_WORD}
_EN_WORDS = set(EN_ONES) | set(EN_TENS) | set(EN_SCALES)
NUMWORDS = _ID_WORDS | _EN_WORDS | set(MULT) | {"and", "dan", ID_TEEN_WORD}


def _norm(t):
    return unicodedata.normalize("NFC", t or "").lower()


# --------------------------------------------------------------------------- #
# Indonesian magnitude parser
# --------------------------------------------------------------------------- #
def _expand_se(tokens):
    """Expand 'se'-prefixed contractions into 'satu <scale>' token pairs."""
    out = []
    for t in tokens:
        if t in ID_SE_FORMS:
            out.extend(ID_SE_FORMS[t])
        else:
            out.append(t)
    return out


def _id_is_numword(tok):
    return (tok in ID_ONES or tok in ID_SCALES or tok in ID_SE_FORMS
            or tok == ID_TEEN_WORD)


def _parse_id_below_thousand(tokens):
    """Parse a group with value below 1000 -> int, treating ratus (hundreds),
    puluh (tens), belas (teens) and ones as separate positional slots so each
    is committed to the subtotal before the next begins, e.g.
    'dua ratus lima puluh' -> 200 + 50 = 250 (not 2050)."""
    subtotal = 0   # committed hundreds
    current = 0    # digit awaiting a scale (ratus/puluh/belas) or a final add
    i = 0
    n = len(tokens)
    while i < n:
        t = tokens[i]
        if t == "ratus":
            subtotal += (current if current else 1) * 100
            current = 0
        elif t == "puluh":
            subtotal += (current if current else 1) * 10
            current = 0
        elif t == ID_TEEN_WORD:            # "<n> belas" -> 10 + n
            subtotal += 10 + current
            current = 0
        elif t in ID_ONES:
            current += ID_ONES[t]
        i += 1
    return subtotal + current


def _parse_id_magnitude(tokens):
    """Parse a run of Indonesian magnitude number words -> int.

    Splits on the big multiplicative scales (juta, ribu) so each preceding group
    is parsed below-thousand and multiplied, e.g.
    'dua ratus lima puluh ribu' -> (2*100 + 5*10) * 1000 = 250000
    'dua juta lima ratus ribu'  -> 2*1e6 + (5*100)*1000 = 2500000
    """
    tokens = _expand_se(tokens)
    total = 0
    group = []
    i = 0
    n = len(tokens)
    while i < n:
        t = tokens[i]
        if t in ("juta", "miliar", "milyar"):
            g = _parse_id_below_thousand(group)
            total += (g if g else 1) * ID_SCALES[t]
            group = []
        elif t == "ribu":
            g = _parse_id_below_thousand(group)
            total += (g if g else 1) * 1000
            group = []
        else:
            group.append(t)
        i += 1
    total += _parse_id_below_thousand(group)
    return total


# --------------------------------------------------------------------------- #
# English magnitude parser (fallback)
# --------------------------------------------------------------------------- #
def _en_has_scale(tokens):
    return any(t in EN_SCALES for t in tokens)


def _parse_en_magnitude(tokens):
    total = 0
    current = 0
    for t in tokens:
        if t in EN_ONES:
            current += EN_ONES[t]
        elif t in EN_TENS:
            current += EN_TENS[t]
        elif t == "hundred":
            current = (current or 1) * 100
        elif t in ("thousand", "million", "billion"):
            total += (current or 1) * EN_SCALES[t]
            current = 0
        elif t in ("and",):
            continue
    return total + current


# --------------------------------------------------------------------------- #
# Digit-by-digit
# --------------------------------------------------------------------------- #
def _token_single_digit(tok):
    """Return the digit string for a single number token, else ''."""
    if tok in ID_ONES:
        return str(ID_ONES[tok])
    if tok in EN_ONES and EN_ONES[tok] < 10:
        return str(EN_ONES[tok])
    if re.search(r"\d", tok):
        return re.sub(r"[.\-,_ ]", "", tok)
    return ""


def convert(text: str) -> str:
    t = _norm(text)
    # normalize currency/symbol noise (rupiah, peso just in case, generic)
    t = (t.replace("₱", " ").replace("rp", " ").replace("rp.", " ")
           .replace("rupiah", " ").replace("php", " ")
           .replace("pesos", " ").replace("peso", " "))
    raw = re.split(r"\s+", t)
    tokens = [x for x in raw if x != ""]

    def core_of(tok):
        return tok.strip(".,;:!?()[]{}\"'`-/")

    def is_number_token(tok):
        c = core_of(tok)
        if c in NUMWORDS and c not in ("and", "dan"):
            return True
        if re.search(r"\d", c):
            return True
        return False

    out = []
    i = 0
    n = len(tokens)
    while i < n:
        core = core_of(tokens[i])
        starts_run = (core in NUMWORDS and core not in ("and", "dan")) or bool(re.search(r"\d", core))
        if starts_run:
            j = i
            run = []
            while j < n and is_number_token(tokens[j]):
                cj = core_of(tokens[j])
                if cj in ("and", "dan"):
                    break
                run.append(core_of(tokens[j]))
                j += 1
            # trim trailing connectors
            while run and run[-1] in ("and", "dan"):
                run.pop(); j -= 1
            if not run:
                out.append(tokens[i]); i += 1; continue

            has_id_scale = any(w in ID_SCALES or w in ID_SE_FORMS or w == ID_TEEN_WORD for w in run)
            has_en_scale = _en_has_scale(run)

            if has_id_scale:
                out.append(str(_parse_id_magnitude(run)))
            elif has_en_scale:
                out.append(str(_parse_en_magnitude(run)))
            else:
                # digit-by-digit (phone numbers etc.), honoring double/triple
                digits = []
                k = 0
                m = len(run)
                while k < m:
                    ck = run[k]
                    if ck in MULT and k + 1 < m:
                        nxt = _token_single_digit(run[k + 1])
                        if len(nxt) == 1:
                            digits.append(nxt * MULT[ck])
                            k += 2
                            continue
                    digits.append(_token_single_digit(run[k]))
                    k += 1
                out.append("".join(digits))
            i = j
        else:
            out.append(tokens[i]); i += 1

    result = re.sub(r"\s+", " ", " ".join(out)).strip()
    return result


if __name__ == "__main__":
    tests = [
        # Indonesian digit-by-digit (phone numbers)
        ("nol delapan satu dua tiga empat lima enam tujuh delapan sembilan", "08123456789"),
        ("0812-3456-7890", "081234567890"),
        # Indonesian magnitudes / money
        ("seratus ribu", "100000"),
        ("dua ratus lima puluh ribu", "250000"),
        ("dua juta lima ratus ribu", "2500000"),
        ("seribu", "1000"),
        ("dua puluh lima", "25"),
        ("sebelas", "11"),
        ("tiga belas", "13"),
        ("sepuluh", "10"),
        ("100.000", "100000"),
        # English fallback
        ("one hundred thousand", "100000"),
        ("double seven eight", "778"),
        # prose must NOT be mangled
        ("terima kasih atas bantuannya", "terima kasih atas bantuannya"),
        ("nomor saya nol delapan satu dua", "nomor saya 0812"),
    ]
    for src, exp in tests:
        got = convert(src)
        print(f"[{'OK ' if got==exp else 'DIFF'}] {src!r} -> {got!r}" + ("" if got==exp else f"  exp {exp!r}"))
