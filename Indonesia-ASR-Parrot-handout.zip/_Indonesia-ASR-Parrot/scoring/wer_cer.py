#!/usr/bin/env python3
"""
wer_cer.py — Score live Amazon Connect (Deepgram) Bahasa Indonesia ASR
hypotheses against the ground-truth phrase list, producing per-utterance and
aggregate WER / CER.

Pipeline this fits into
-----------------------
    Human tester reads an Indonesian phrase  (= REFERENCE / ground truth)
          │  speech
          ▼
    Amazon Connect Agentic Voice → Deepgram STT  (= HYPOTHESIS)
          │  text, auto-logged to the Q-in-Connect (wisdom) CloudWatch transcript
          ▼
    CloudWatch log  (each CUSTOMER turn = one Deepgram hypothesis)
          │
          ▼
    THIS SCRIPT: align reference vs hypothesis → WER / CER report (CSV + XLSX)

Design notes
------------
* Uses a standard jiwer-based CER/WER (lowercase + strip normalization). An
  inline jiwer implementation is included so this folder is self-contained.
* CER is the primary metric. WER is reported too but can be inflated by
  digit/number recombination, so we ALSO report a "digits-normalized" CER/WER
  that neutralises that effect, plus a number-normalized view (Indonesian
  spoken numbers → digits) via num_normalize.py.
* Output columns:
  GroundTruth | Total Characters | ASR | error characters | CER(%) | WER(%)

Sources
-------
References (ground truth), any one of:
  --refs-xlsx  path/to/Indonesia ASR Testing Script.xlsx   (reads GroundTruth col)
  --refs-csv   path/to/references.csv   (columns: sequence?, reference)
  --refs-txt   path/to/references.txt   (one phrase per line, sequence = line no.)

Hypotheses (what Deepgram produced), any one of:
  --hyps-jsonl  path/to/hypotheses.jsonl   (records from S3, one JSON per line)
  --hyps-csv    path/to/hypotheses.csv     (columns: sequence?, utterance, contactId?, timestamp?)
  --hyps-ddb    <table-name>               (scan DynamoDB, optional --contact-id filter)
  --hyps-contactlens  path/to/transcript.json  (Contact Lens transcript export, FALLBACK)

Alignment
---------
By default references and hypotheses are aligned by `sequence` (the phrase
number the agent logged, 1-based). If sequence is missing on either side, they
are aligned by order of appearance. Use --align order to force positional.

Usage examples
--------------
  python wer_cer.py \
      --refs-xlsx "/path/Indonesia ASR Testing Script.xlsx" \
      --hyps-jsonl hypotheses.jsonl \
      --out-prefix results/run1

  python wer_cer.py \
      --refs-txt references.txt \
      --hyps-ddb asr-test-vn-transcriptions --contact-id 1a2b-... \
      --out-prefix results/call_1a2b
"""

import argparse
import csv
import glob
import json
import os
import re
import sys
import unicodedata
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Optional


# --------------------------------------------------------------------------- #
# Metrics: reuse the existing project's metrics.py if available.
# --------------------------------------------------------------------------- #
def _load_metrics():
    """Return (calculate_wer, calculate_cer, char_errors_fn) using a
    self-contained jiwer-based implementation (lower + strip normalization)."""
    # Inline implementation (lower + strip normalization).
    try:
        from jiwer import wer as _wer, cer as _cer, process_characters as _pc
    except ImportError:
        sys.exit(
            "jiwer is required. Install with:  pip install jiwer\n"
            "(and openpyxl if reading/writing .xlsx:  pip install openpyxl)"
        )

    def calculate_wer(reference: str, hypothesis: str) -> float:
        if not reference.strip():
            return 1.0 if hypothesis.strip() else 0.0
        if not hypothesis.strip():
            return 1.0
        return _wer(reference.lower().strip(), hypothesis.lower().strip())

    def calculate_cer(reference: str, hypothesis: str) -> float:
        if not reference.strip():
            return 1.0 if hypothesis.strip() else 0.0
        if not hypothesis.strip():
            return 1.0
        return _cer(reference.lower().strip(), hypothesis.lower().strip())

    def get_detailed_char_errors(reference: str, hypothesis: str) -> dict:
        if not reference.strip() or not hypothesis.strip():
            return {
                "substitutions": 0, "insertions": 0, "deletions": 0,
                "hits": 0, "cer": calculate_cer(reference, hypothesis),
            }
        r = _pc(reference.lower().strip(), hypothesis.lower().strip())
        return {
            "substitutions": r.substitutions, "insertions": r.insertions,
            "deletions": r.deletions, "hits": r.hits, "cer": r.cer,
        }

    return calculate_wer, calculate_cer, get_detailed_char_errors, "inline jiwer fallback"


CALC_WER, CALC_CER, CHAR_ERRORS, METRICS_SOURCE = _load_metrics()


# --------------------------------------------------------------------------- #
# Normalization helpers
# --------------------------------------------------------------------------- #
def basic_norm(text: str) -> str:
    """Lowercase + collapse whitespace. Matches the project's lower/strip
    convention while also collapsing internal runs of spaces."""
    text = unicodedata.normalize("NFC", text or "")
    text = text.lower().strip()
    text = re.sub(r"\s+", " ", text)
    return text


_PUNCT_RE = re.compile(r"[.,;:!?()\[\]{}\"'`~^*_/\\|<>@#$%&+=]")


# Spoken-number -> digit conversion (optional, for fair cross-engine
# comparison). For the Bahasa Indonesia test this normalizes INDONESIAN number
# words (Indonesian speakers say numbers/money/dates in Indonesian: "nol delapan
# satu dua", "seratus ribu"). Loaded lazily; toggled by NUMBER_MODE.
try:
    import num_normalize as _vnnum
except ImportError:
    _vnnum = None

NUMBER_MODE = "off"  # "off" or "words2digits"; set from CLI


def apply_number_mode(text: str) -> str:
    """When NUMBER_MODE=='words2digits', convert spoken number-words to digits
    (and strip separators in existing digit runs) so spelled-out numbers compare
    equal to typed numbers. Applied to refs AND hyps identically."""
    if NUMBER_MODE == "words2digits" and _vnnum is not None:
        return _vnnum.convert(text)
    return text


def digits_normalized(text: str) -> str:
    """Neutralise the digit/date recombination effect documented in
    1-wer_cer_walkthrough.md.

    Strategy: strip punctuation and separators inside numbers, then collapse all
    digit runs to a canonical spaced form so that '0912-345-678', '0912 345 678'
    and '0912345678' compare equal, and pure spelled-vs-grouped digit differences
    do not dominate CER. This yields a 'vocabulary-focused' error rate alongside
    the raw one. It does NOT convert spelled-out numerals to digits (that is
    what --number-mode words2digits does); it only canonicalises already-digit
    sequences and removes punctuation.
    """
    t = basic_norm(text)
    t = _PUNCT_RE.sub(" ", t)
    # Join digits separated only by spaces/dots into a single run,
    # e.g. "0912 345 678" -> "0912345678"
    t = re.sub(r"(?<=\d)[ \t]+(?=\d)", "", t)
    t = re.sub(r"\s+", " ", t).strip()
    return t


# --------------------------------------------------------------------------- #
# Data model
# --------------------------------------------------------------------------- #
@dataclass
class Pair:
    sequence: Optional[int]
    reference: str
    hypothesis: str
    contact_id: str = ""
    timestamp: str = ""
    intent: str = ""          # optional, from TCB sheet2
    expected_action: str = ""  # optional, from TCB sheet2


# --------------------------------------------------------------------------- #
# Reference loaders
# --------------------------------------------------------------------------- #
# Phrases in the TCB sheet that are column headers, not test phrases.
_HEADER_TOKENS = {
    "groundtruth", "total characters", "test1 asr", "session id",
    "test1 error characters", "test1 cer(%)", "test2 asr",
    "test2 error characters", "test2 cer(%)", "total cer(%)",
    "expected intent", "expected action", "correct intent?", "notes",
    "model", "multi or mono", "language", "bcp-47 variant", "audio",
    "expected (correct) textual output", "actual textual output",
    "amazon call id", "request id", "transcription category",
    "sanity test output", "testing notes & observations",
}


def load_refs_xlsx(path: str) -> list[tuple[Optional[int], str, str, str]]:
    """Read GroundTruth phrases from the TCB spreadsheet.
    Returns list of (sequence, reference, intent, expected_action)."""
    try:
        from openpyxl import load_workbook
    except ImportError:
        sys.exit("openpyxl required to read .xlsx:  pip install openpyxl")

    wb = load_workbook(path, read_only=True, data_only=True)
    refs: list[tuple[Optional[int], str, str, str]] = []
    seq = 0
    for ws in wb.worksheets:
        rows = list(ws.iter_rows(values_only=True))
        if not rows:
            continue
        header = [str(c).strip().lower() if c is not None else "" for c in rows[0]]
        # Only treat a sheet as a phrase sheet if it has an explicit
        # "groundtruth" header column. This deliberately SKIPS metadata sheets
        # (e.g. model-info sheets whose phrase column is "expected (correct)
        # textual output") and free-text notes sheets that have no header,
        # which would otherwise pollute the reference list.
        if "groundtruth" not in header:
            continue
        gt_col = header.index("groundtruth")
        intent_col = header.index("expected intent") if "expected intent" in header else None
        action_col = header.index("expected action") if "expected action" in header else None

        for row in rows[1:]:
            if not row or gt_col >= len(row):
                continue
            cell = row[gt_col]
            if cell is None:
                continue
            phrase = str(cell).strip()
            if not phrase or phrase.lower() in _HEADER_TOKENS:
                continue
            intent = ""
            action = ""
            if intent_col is not None and intent_col < len(row) and row[intent_col]:
                intent = str(row[intent_col]).strip()
            if action_col is not None and action_col < len(row) and row[action_col]:
                action = str(row[action_col]).strip()
            seq += 1
            refs.append((seq, phrase, intent, action))
    wb.close()
    return refs


def load_refs_csv(path: str) -> list[tuple[Optional[int], str, str, str]]:
    refs = []
    with open(path, encoding="utf-8-sig", newline="") as f:
        reader = csv.DictReader(f)
        fields = [c.lower() for c in (reader.fieldnames or [])]
        if "reference" in fields or "groundtruth" in fields:
            ref_key = "reference" if "reference" in fields else "groundtruth"
            for i, row in enumerate(reader, start=1):
                lower = {k.lower(): v for k, v in row.items()}
                phrase = (lower.get(ref_key) or "").strip()
                if not phrase:
                    continue
                seq = lower.get("sequence")
                seq = int(seq) if seq and str(seq).isdigit() else i
                refs.append((seq, phrase, lower.get("expected intent", "") or "", ""))
        else:
            # headerless: treat first column as phrase
            f.seek(0)
            for i, row in enumerate(csv.reader(f), start=1):
                if row and row[0].strip():
                    refs.append((i, row[0].strip(), "", ""))
    return refs


def load_refs_txt(path: str) -> list[tuple[Optional[int], str, str, str]]:
    refs = []
    with open(path, encoding="utf-8") as f:
        seq = 0
        for line in f:
            phrase = line.strip()
            if phrase:
                seq += 1
                refs.append((seq, phrase, "", ""))
    return refs


# --------------------------------------------------------------------------- #
# Hypothesis loaders
# --------------------------------------------------------------------------- #
def _hyp_record(seq, utterance, contact_id="", timestamp=""):
    return {
        "sequence": seq,
        "utterance": utterance or "",
        "contactId": contact_id or "",
        "timestamp": timestamp or "",
    }


def load_hyps_jsonl(path: str) -> list[dict]:
    """Load hypotheses from JSONL, or from a directory / glob of per-record
    JSON files (matching the S3 layout asr-test/hypotheses/<contactId>/*.json)."""
    records = []
    paths = []
    if os.path.isdir(path):
        paths = sorted(glob.glob(os.path.join(path, "**", "*.json"), recursive=True))
    elif any(ch in path for ch in "*?[") or "**" in path:
        paths = sorted(glob.glob(path, recursive=True))
    if paths:
        for p in paths:
            try:
                with open(p, encoding="utf-8") as f:
                    obj = json.load(f)
                records.append(_norm_hyp_obj(obj))
            except (ValueError, OSError):
                continue
        return records
    # single JSONL file
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                obj = json.loads(line)
            except ValueError:
                continue
            records.append(_norm_hyp_obj(obj))
    return records


def _norm_hyp_obj(obj: dict) -> dict:
    seq = obj.get("sequence")
    try:
        seq = int(seq)
        if seq < 0:
            seq = None
    except (TypeError, ValueError):
        seq = None
    return _hyp_record(
        seq,
        obj.get("utterance") or obj.get("transcription") or obj.get("text") or "",
        obj.get("contactId") or obj.get("contact_id") or "",
        obj.get("timestamp") or "",
    )


def load_hyps_csv(path: str) -> list[dict]:
    records = []
    with open(path, encoding="utf-8-sig", newline="") as f:
        reader = csv.DictReader(f)
        for i, row in enumerate(reader, start=1):
            lower = {k.lower(): v for k, v in row.items()}
            utt = (lower.get("utterance") or lower.get("asr") or lower.get("hypothesis") or "").strip()
            if not utt:
                continue
            seq = lower.get("sequence")
            seq = int(seq) if seq and str(seq).isdigit() else None
            records.append(_hyp_record(seq, utt, lower.get("contactid", ""), lower.get("timestamp", "")))
    return records


def load_hyps_ddb(table_name: str, contact_id: Optional[str]) -> list[dict]:
    try:
        import boto3
        from boto3.dynamodb.conditions import Key
    except ImportError:
        sys.exit("boto3 required for --hyps-ddb:  pip install boto3")
    table = boto3.resource("dynamodb").Table(table_name)
    items = []
    if contact_id:
        resp = table.query(KeyConditionExpression=Key("contactId").eq(contact_id))
        items.extend(resp.get("Items", []))
        while "LastEvaluatedKey" in resp:
            resp = table.query(
                KeyConditionExpression=Key("contactId").eq(contact_id),
                ExclusiveStartKey=resp["LastEvaluatedKey"],
            )
            items.extend(resp.get("Items", []))
    else:
        resp = table.scan()
        items.extend(resp.get("Items", []))
        while "LastEvaluatedKey" in resp:
            resp = table.scan(ExclusiveStartKey=resp["LastEvaluatedKey"])
            items.extend(resp.get("Items", []))
    records = [_norm_hyp_obj(it) for it in items]
    # Sort by (contactId, sequence, timestamp) for stable ordering.
    records.sort(key=lambda r: (r["contactId"], r["sequence"] if r["sequence"] is not None else 1 << 30, r["timestamp"]))
    return records


def load_hyps_cloudwatch(log_group: str, region: str, session_or_contact: Optional[str],
                         stream: str = "QiCAssistantTranscript") -> list[dict]:
    """Load Deepgram hypotheses directly from the Q in Connect (wisdom) CloudWatch
    transcript log — the authoritative platform record of what Deepgram
    transcribed. No Lambda / DynamoDB needed.

    Each CUSTOMER turn's text value IS the Deepgram hypothesis. We sort by the
    event timestamp (CloudWatch can return turns slightly out of order) and
    number them by order of appearance, since these logs carry no explicit
    per-phrase sequence.

    session_or_contact: optionally filter to one call by its session_name
    (which equals the Connect contactId). If None, returns all CUSTOMER turns
    in the stream (use for a single-call test log).
    """
    try:
        import boto3
    except ImportError:
        sys.exit("boto3 required for --hyps-cloudwatch:  pip install boto3")
    logs = boto3.client("logs", region_name=region)

    events = []
    kwargs = dict(logGroupName=log_group, logStreamName=stream,
                  startFromHead=True, limit=10000)
    token = None
    while True:
        if token:
            kwargs["nextToken"] = token
        resp = logs.get_log_events(**kwargs)
        batch = resp.get("events", [])
        events.extend(batch)
        new_token = resp.get("nextForwardToken")
        if not batch or new_token == token:
            break
        token = new_token

    # The contactId appears as session_name ONLY on the CREATE_SESSION event;
    # individual turn events carry session_id instead. Build a contactId ->
    # session_id map so we can filter turns correctly.
    parsed = []
    contact_to_session = {}
    for ev in events:
        try:
            e = json.loads(ev.get("message", ""))
        except ValueError:
            continue
        parsed.append(e)
        if e.get("event_type") == "TRANSCRIPT_CREATE_SESSION":
            name = e.get("session_name")
            sid = e.get("session_id")
            if name and sid:
                contact_to_session[name] = sid

    target_session_id = None
    if session_or_contact:
        # Accept either a contactId (mapped) or a raw session_id.
        target_session_id = contact_to_session.get(session_or_contact, session_or_contact)

    # Sentinel emitted by Agentic Voice when a turn captured no speech.
    _EMPTY_MARKERS = {"<empty_user_input>", "<no_input>", "<empty>"}

    def _last_user_text(prompt_field):
        """From a TRANSCRIPT_AGENTIC_MESSAGE 'prompt' (JSON string or dict),
        return the newest customer utterance = the last role:'user' text in the
        messages array. Returns '' if none / empty-input sentinel."""
        try:
            pr = prompt_field if isinstance(prompt_field, dict) else json.loads(prompt_field)
        except (ValueError, TypeError):
            return ""
        latest = ""
        for m in pr.get("messages", []):
            if m.get("role") != "user":
                continue
            for c in m.get("content", []):
                t = c.get("text") if isinstance(c, dict) else None
                if t and str(t).strip():
                    latest = str(t).strip()
        if latest.lower() in _EMPTY_MARKERS:
            return ""
        return latest

    rows = []  # (timestamp, text, session_id)
    for e in parsed:
        if target_session_id and e.get("session_id") != target_session_id:
            continue
        et = e.get("event_type")

        # --- Newer Agentic Voice schema: TRANSCRIPT_AGENTIC_MESSAGE ---
        # The customer's Deepgram hypothesis for this turn is the last
        # role:'user' text inside the prompt's messages array. (There is no
        # separate CUSTOMER turn event and no 'participant' field.)
        if et == "TRANSCRIPT_AGENTIC_MESSAGE":
            text = _last_user_text(e.get("prompt", ""))
            if text:
                rows.append((e.get("event_timestamp", 0), text, e.get("session_id", "")))
            continue

        # --- Older schema: TRANSCRIPT_ORCHESTRATION_MESSAGE, CUSTOMER turns ---
        if et == "TRANSCRIPT_ORCHESTRATION_MESSAGE" and e.get("participant") == "CUSTOMER":
            v = e.get("values", "")
            try:
                vv = json.loads(v)
            except ValueError:
                continue
            for it in vv:
                if it.get("type") == "text" and str(it.get("value", "")).strip():
                    rows.append((e.get("event_timestamp", 0),
                                 it["value"].strip(),
                                 e.get("session_id", "")))

    rows.sort(key=lambda r: r[0])

    # De-duplicate consecutive identical utterances within the same session.
    # The Agentic Voice schema logs each turn's running prompt more than once
    # (e.g. a streaming/finalization pair), so the same newest customer text
    # appears back-to-back. Those are the SAME spoken turn, not two reads —
    # collapse them so alignment/scoring see one hypothesis per turn.
    deduped = []
    for ts, text, sess in rows:
        if deduped:
            _pts, ptext, psess = deduped[-1]
            if psess == sess and _norm_txt(ptext) == _norm_txt(text):
                continue
        deduped.append((ts, text, sess))

    records = []
    for i, (_ts, text, sess) in enumerate(deduped, start=1):
        records.append(_hyp_record(i, text, session_or_contact or sess, ""))
    return records


def _norm_txt(s: str) -> str:
    """Loose comparison key for dedup: lowercase, collapse whitespace."""
    return re.sub(r"\s+", " ", (s or "").strip().lower())


# Very short, contentless turns an ASR engine sometimes emits from a breath,
# cough, or the tail of the agent's prompt (seen on Contact Lens / Amazon
# Transcribe). These are NOT phrase reads and, if kept, shift every later turn
# out of alignment. Matched case-insensitively after stripping punctuation.
_JUNK_TURNS = {
    "nah", "uh", "um", "hmm", "hm", "eh", "ah", "oh", "ya", "yah", "ok", "okay",
    "mm", "mmm", "huh", "hah", "ha",
}


def is_junk_turn(text: str) -> bool:
    """True if a turn is a contentless noise token (breath/filler) rather than a
    real spoken phrase — used to drop stray turns before alignment so they don't
    cause an off-by-one cascade."""
    core = re.sub(r"[^\w\s]", "", (text or "")).strip().lower()
    if not core:
        return True
    # single filler word, or a couple of repeated filler words
    words = core.split()
    if len(words) <= 2 and all(wd in _JUNK_TURNS for wd in words):
        return True
    return False


def load_hyps_contactlens(path: str) -> list[dict]:
    """Extract caller turns from a Contact Lens transcript export.

    IMPORTANT: Contact Lens transcripts are produced by AMAZON TRANSCRIBE, a
    DIFFERENT ASR engine than Deepgram. These caller turns are Amazon
    Transcribe's hypotheses, NOT Deepgram's. Use this only for engine
    comparison (see compare_engines.py), never as a substitute for the Deepgram
    LogTranscription data when measuring Deepgram accuracy."""
    with open(path, encoding="utf-8") as f:
        data = json.load(f)
    turns = data.get("Transcript") or data.get("transcript") or []
    records = []
    seq = 0
    for t in turns:
        participant = (t.get("ParticipantId") or t.get("participantId") or "").upper()
        role = (t.get("ParticipantRole") or t.get("participantRole") or "").upper()
        content = t.get("Content") or t.get("content") or ""
        # Caller/customer turns only.
        if "CUSTOMER" in participant or "CUSTOMER" in role or participant == "AGENT" and False:
            if content.strip() and not is_junk_turn(content):
                seq += 1
                records.append(_hyp_record(seq, content.strip(), data.get("ContactId", ""), t.get("BeginOffsetMillis", "")))
    return records


# --------------------------------------------------------------------------- #
# Alignment
# --------------------------------------------------------------------------- #
def align(refs, hyps, mode: str) -> list[Pair]:
    pairs: list[Pair] = []
    ref_have_seq = all(r[0] is not None for r in refs) and len(refs) > 0
    hyp_have_seq = all(h["sequence"] is not None for h in hyps) and len(hyps) > 0

    if mode == "sequence" and ref_have_seq and hyp_have_seq:
        hyp_by_seq: dict[int, dict] = {}
        for h in hyps:
            # if duplicate sequences, keep the last (most recent)
            hyp_by_seq[h["sequence"]] = h
        for seq, ref, intent, action in refs:
            h = hyp_by_seq.get(seq)
            pairs.append(Pair(
                sequence=seq, reference=ref,
                hypothesis=(h["utterance"] if h else ""),
                contact_id=(h["contactId"] if h else ""),
                timestamp=(h["timestamp"] if h else ""),
                intent=intent, expected_action=action,
            ))
        return pairs

    if mode == "best-match":
        return align_best_match(refs, hyps)

    # positional
    n = max(len(refs), len(hyps))
    for i in range(n):
        seq, ref, intent, action = refs[i] if i < len(refs) else (i + 1, "", "", "")
        h = hyps[i] if i < len(hyps) else None
        pairs.append(Pair(
            sequence=(seq if seq is not None else i + 1),
            reference=ref,
            hypothesis=(h["utterance"] if h else ""),
            contact_id=(h["contactId"] if h else ""),
            timestamp=(h["timestamp"] if h else ""),
            intent=intent, expected_action=action,
        ))
    return pairs


def align_best_match(refs, hyps) -> list[Pair]:
    """Content-based alignment that is resilient to dropped/extra/mis-ordered
    phrases.

    Each hypothesis (taken in call order) is matched to the reference it fits
    best (lowest digits-normalized CER), searching a forward window from the
    last matched reference so matches stay roughly monotonic (callers read the
    list top-to-bottom, but a phrase may be skipped). References that never win
    a hypothesis are emitted as MISSING. Hypotheses that match nothing well are
    still attached to their best reference but flagged in the CER.

    This fixes the cascade problem where one dropped phrase makes every later
    positional pair compare mismatched text.
    """
    # Two-pass assignment:
    #  Pass 1 (anchors): match hypotheses that have CONFIDENT word overlap to
    #    their reference. This establishes the correct sequence skeleton and
    #    lets us skip references that were never spoken.
    #  Pass 2 (gap fill): place any remaining (e.g. badly-mangled) hypotheses
    #    positionally into the reference GAPS between anchors, in order. This
    #    keeps a spoken-but-garbled phrase scored (with its real high CER)
    #    instead of dropping it, while still not misaligning across a truly
    #    dropped phrase.
    #
    # Matching signal is non-digit word OVERLAP, not CER: Deepgram spells
    # numbers out as words, so CER is high even for correct matches, but the
    # distinctive lead words identify the right reference reliably.
    def word_tokens(text):
        t = digits_normalized(text)
        return [tok for tok in t.split() if not tok.isdigit()]

    def overlap_score(ref_text, hyp_text):
        r = word_tokens(ref_text)
        h = set(word_tokens(hyp_text))
        if not r:
            return 0.0
        return sum(1 for tok in r if tok in h) / len(r)

    ANCHOR_THRESHOLD = 0.50   # high-confidence match -> anchor outright
    SOFT_THRESHOLD = 0.20     # weaker match still anchors if it's the CLEAR winner
    FORWARD_WINDOW = 8
    n_ref = len(refs)
    assignments: dict[int, dict] = {}   # ref_index -> hyp record
    anchored_ref = [False] * n_ref
    hyp_anchored = [False] * len(hyps)
    last_ref = -1

    # ---- Pass 1: confident anchors, monotonic forward ----
    for hi, h in enumerate(hyps):
        end = min(n_ref, (last_ref + 1) + FORWARD_WINDOW)
        candidates = [i for i in range(last_ref + 1, end) if not anchored_ref[i]]
        if not candidates:
            candidates = [i for i in range(n_ref) if not anchored_ref[i]]
        # rank candidates by overlap
        scored_c = sorted(((overlap_score(refs[i][1], h["utterance"]), i)
                           for i in candidates), reverse=True)
        if not scored_c:
            continue
        best_score, best_idx = scored_c[0]
        second = scored_c[1][0] if len(scored_c) > 1 else 0.0
        # Anchor if strongly matched, OR if it's a clear unique winner above a
        # soft floor (distinctive lead words like "saldo saya" identify the
        # right reference even when most of the phrase is a spelled-out number
        # the hypothesis rendered as digits). "Clear winner" = beats the runner
        # up by a margin, so we never anchor on an ambiguous tie.
        is_clear_winner = best_score >= SOFT_THRESHOLD and best_score >= second + 0.15
        if best_idx is not None and (best_score >= ANCHOR_THRESHOLD or is_clear_winner):
            assignments[best_idx] = h
            anchored_ref[best_idx] = True
            hyp_anchored[hi] = True
            last_ref = max(last_ref, best_idx)

    # ---- Pass 2: place leftover hyps into ref gaps, preserving order ----
    leftover = [h for hi, h in enumerate(hyps) if not hyp_anchored[hi]]
    if leftover:
        # Walk references in order; drop each leftover hyp into the next
        # not-yet-anchored reference slot that sits AT OR AFTER the previous
        # anchor region, so it stays between the correct neighbours.
        free_slots = [i for i in range(n_ref) if not anchored_ref[i]]
        # Prefer slots that are "interior" gaps (between two anchors) in order.
        li = 0
        for slot in free_slots:
            if li >= len(leftover):
                break
            # Only fill a gap slot if there is an anchor before it OR it's at
            # the start; this keeps mangled phrases near where they were spoken
            # and avoids dumping them into the long tail of unspoken refs.
            has_anchor_before = any(anchored_ref[j] for j in range(0, slot))
            has_anchor_after = any(anchored_ref[j] for j in range(slot + 1, n_ref))
            if has_anchor_before and has_anchor_after:
                assignments[slot] = leftover[li]
                li += 1
        # If some leftovers remain (e.g. before the first anchor), place them
        # into the earliest free slots in order.
        if li < len(leftover):
            for slot in free_slots:
                if slot in assignments:
                    continue
                if li >= len(leftover):
                    break
                assignments[slot] = leftover[li]
                li += 1

    pairs: list[Pair] = []
    for i, (seq, ref, intent, action) in enumerate(refs):
        h = assignments.get(i)
        pairs.append(Pair(
            sequence=(seq if seq is not None else i + 1),
            reference=ref,
            hypothesis=(h["utterance"] if h else ""),
            contact_id=(h["contactId"] if h else ""),
            timestamp=(h["timestamp"] if h else ""),
            intent=intent, expected_action=action,
        ))
    return pairs


# --------------------------------------------------------------------------- #
# Scoring
# --------------------------------------------------------------------------- #
@dataclass
class Scored:
    pair: Pair
    total_chars: int
    cer: float
    wer: float
    error_chars: int
    cer_norm: float
    wer_norm: float
    matched: bool


def score_pairs(pairs: list[Pair]) -> list[Scored]:
    out = []
    for p in pairs:
        # Optionally convert Indonesian spoken numbers to digits first, so
        # spelled-out numbers compare fairly against typed numbers.
        ref_text = apply_number_mode(p.reference)
        hyp_text = apply_number_mode(p.hypothesis)

        ref_n = basic_norm(ref_text)
        hyp_n = basic_norm(hyp_text)
        total_chars = len(ref_n)
        cer = CALC_CER(ref_text, hyp_text)
        wer = CALC_WER(ref_text, hyp_text)
        # error characters = CER * reference length (matches TCB "error characters" column)
        err = CHAR_ERRORS(ref_text, hyp_text)
        error_chars = int(err.get("substitutions", 0) + err.get("insertions", 0) + err.get("deletions", 0))

        rd = digits_normalized(ref_text)
        hd = digits_normalized(hyp_text)
        cer_norm = CALC_CER(rd, hd)
        wer_norm = CALC_WER(rd, hd)

        out.append(Scored(
            pair=p,
            total_chars=total_chars,
            cer=cer, wer=wer, error_chars=error_chars,
            cer_norm=cer_norm, wer_norm=wer_norm,
            matched=bool(p.hypothesis.strip()),
        ))
    return out


def aggregate(scored: list[Scored]) -> dict:
    matched = [s for s in scored if s.matched]
    n = len(matched)

    def avg(fn):
        return sum(fn(s) for s in matched) / n if n else 0.0

    # Micro (corpus-level) CER: total edit distance / total ref chars.
    total_ref_chars = sum(s.total_chars for s in matched)
    total_err_chars = sum(s.error_chars for s in matched)
    micro_cer = (total_err_chars / total_ref_chars) if total_ref_chars else 0.0

    return {
        "phrases_total": len(scored),
        "phrases_matched": n,
        "phrases_missing": len(scored) - n,
        "macro_cer": avg(lambda s: s.cer),
        "macro_wer": avg(lambda s: s.wer),
        "macro_cer_digitsnorm": avg(lambda s: s.cer_norm),
        "macro_wer_digitsnorm": avg(lambda s: s.wer_norm),
        "micro_cer": micro_cer,
        "total_ref_chars": total_ref_chars,
        "total_error_chars": total_err_chars,
    }


# --------------------------------------------------------------------------- #
# Output
# --------------------------------------------------------------------------- #
def pct(x: float) -> str:
    return f"{x * 100:.2f}%"


def write_csv(scored: list[Scored], out_csv: str):
    os.makedirs(os.path.dirname(out_csv) or ".", exist_ok=True)
    with open(out_csv, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f)
        w.writerow([
            "Sequence", "ContactId", "Timestamp",
            "GroundTruth", "Total Characters", "ASR (Deepgram hypothesis)",
            "error characters", "CER(%)", "WER(%)",
            "CER digits-norm(%)", "WER digits-norm(%)",
            "Expected Intent", "Expected Action", "Captured?",
        ])
        for s in scored:
            p = s.pair
            w.writerow([
                p.sequence, p.contact_id, p.timestamp,
                p.reference, s.total_chars, p.hypothesis,
                s.error_chars, pct(s.cer), pct(s.wer),
                pct(s.cer_norm), pct(s.wer_norm),
                p.intent, p.expected_action,
                "yes" if s.matched else "MISSING",
            ])


def write_xlsx(scored: list[Scored], agg: dict, out_xlsx: str):
    try:
        from openpyxl import Workbook
    except ImportError:
        print("  (openpyxl not installed; skipping .xlsx — CSV still written)")
        return
    os.makedirs(os.path.dirname(out_xlsx) or ".", exist_ok=True)
    wb = Workbook()
    ws = wb.active
    ws.title = "Per-Utterance"
    ws.append([
        "Sequence", "ContactId", "Timestamp",
        "GroundTruth", "Total Characters", "ASR (Deepgram hypothesis)",
        "error characters", "CER(%)", "WER(%)",
        "CER digits-norm(%)", "WER digits-norm(%)",
        "Expected Intent", "Expected Action", "Captured?",
    ])
    for s in scored:
        p = s.pair
        ws.append([
            p.sequence, p.contact_id, p.timestamp,
            p.reference, s.total_chars, p.hypothesis,
            s.error_chars, round(s.cer * 100, 2), round(s.wer * 100, 2),
            round(s.cer_norm * 100, 2), round(s.wer_norm * 100, 2),
            p.intent, p.expected_action,
            "yes" if s.matched else "MISSING",
        ])
    ws2 = wb.create_sheet("Summary")
    for k, v in agg.items():
        if isinstance(v, float) and k.startswith(("macro", "micro")):
            ws2.append([k, round(v * 100, 2), "%"])
        else:
            ws2.append([k, v])
    wb.save(out_xlsx)


def print_summary(agg: dict):
    print("\n" + "=" * 60)
    print("  BAHASA INDONESIA ASR ACCURACY SUMMARY (Deepgram via Connect)")
    print("=" * 60)
    print(f"  Metrics engine     : {METRICS_SOURCE}")
    print(f"  Phrases (total)    : {agg['phrases_total']}")
    print(f"  Phrases (captured) : {agg['phrases_matched']}")
    if agg["phrases_missing"]:
        print(f"  Phrases MISSING    : {agg['phrases_missing']}  (no hypothesis captured)")
    print("-" * 60)
    print("  PRIMARY METRIC — Character Error Rate (Bahasa Indonesia):")
    print(f"    CER  macro (avg per phrase) : {pct(agg['macro_cer'])}")
    print(f"    CER  micro (corpus-level)   : {pct(agg['micro_cer'])}")
    print(f"    WER  macro (avg per phrase) : {pct(agg['macro_wer'])}")
    print("-" * 60)
    print("  DIGITS-NORMALIZED (neutralises digit/date recombination):")
    print(f"    CER  macro : {pct(agg['macro_cer_digitsnorm'])}")
    print(f"    WER  macro : {pct(agg['macro_wer_digitsnorm'])}")
    print("=" * 60)
    print("  Note: raw WER/CER can be inflated by how numbers are written")
    print("  (Deepgram may spell '08123' as 'nol delapan satu dua tiga').")
    print("  Use --number-mode words2digits and read the number-normalized")
    print("  columns for the truest recognition accuracy.\n")


# --------------------------------------------------------------------------- #
# Main
# --------------------------------------------------------------------------- #
def main():
    ap = argparse.ArgumentParser(description="Score Connect/Deepgram Bahasa Indonesia ASR against a ground-truth phrase list.")
    # references
    g_ref = ap.add_mutually_exclusive_group(required=True)
    g_ref.add_argument("--refs-xlsx", help="Testing spreadsheet with a GroundTruth column")
    g_ref.add_argument("--refs-csv", help="CSV with a 'reference'/'groundtruth' column")
    g_ref.add_argument("--refs-txt", help="Plain text, one phrase per line")
    # hypotheses
    g_hyp = ap.add_mutually_exclusive_group(required=True)
    g_hyp.add_argument("--hyps-jsonl", help="JSONL file, or a dir/glob of per-record JSON (S3 layout)")
    g_hyp.add_argument("--hyps-csv", help="CSV with an 'utterance'/'asr' column")
    g_hyp.add_argument("--hyps-ddb", help="DynamoDB table name to scan/query")
    g_hyp.add_argument("--hyps-cloudwatch", metavar="LOG_GROUP",
                       help="Read Deepgram hypotheses straight from the Q-in-Connect wisdom CloudWatch log group (e.g. /aws/wisdom/assistant/<id>). No Lambda/DDB needed. Filter one call with --contact-id.")
    g_hyp.add_argument("--hyps-contactlens", help="Contact Lens transcript JSON. WARNING: this is AMAZON TRANSCRIBE output, NOT Deepgram. Do NOT use it for Deepgram WER/CER. For engine comparison use compare_engines.py instead.")
    ap.add_argument("--contact-id", help="Filter by contactId (with --hyps-ddb or --hyps-cloudwatch; the wisdom log's session_name == contactId)")
    ap.add_argument("--region", default="ap-southeast-1", help="AWS region for --hyps-cloudwatch / --hyps-ddb")
    ap.add_argument("--cw-stream", default="QiCAssistantTranscript", help="CloudWatch log stream name (default: QiCAssistantTranscript)")
    ap.add_argument("--align", choices=["sequence", "order", "best-match"], default="sequence",
                    help="Alignment strategy. 'sequence' (agent-logged), 'order' (positional), or 'best-match' (content-based, resilient to dropped/mis-ordered phrases). CloudWatch defaults to best-match.")
    ap.add_argument("--out-prefix", default="asr_results",
                    help="Output path prefix; writes <prefix>.csv and <prefix>.xlsx")
    ap.add_argument("--upload-s3", metavar="s3://bucket/prefix",
                    help="Optional: upload the CSV and XLSX result to this S3 location")
    ap.add_argument("--number-mode", choices=["off", "words2digits"], default="off",
                    help="'words2digits' converts Indonesian spoken numbers to digits on BOTH refs and hyps, so spelled-out numbers compare fairly against typed numbers (measures true recognition, not number formatting). Default off.")
    args = ap.parse_args()

    global NUMBER_MODE
    NUMBER_MODE = args.number_mode
    if NUMBER_MODE == "words2digits" and _vnnum is None:
        print("WARNING: num_normalize.py not found; --number-mode words2digits ignored.")

    # Load references
    if args.refs_xlsx:
        refs = load_refs_xlsx(args.refs_xlsx)
    elif args.refs_csv:
        refs = load_refs_csv(args.refs_csv)
    else:
        refs = load_refs_txt(args.refs_txt)
    if not refs:
        sys.exit("No references loaded. Check the ground-truth source.")

    # Load hypotheses
    if args.hyps_jsonl:
        hyps = load_hyps_jsonl(args.hyps_jsonl)
    elif args.hyps_csv:
        hyps = load_hyps_csv(args.hyps_csv)
    elif args.hyps_ddb:
        hyps = load_hyps_ddb(args.hyps_ddb, args.contact_id)
    elif args.hyps_cloudwatch:
        hyps = load_hyps_cloudwatch(args.hyps_cloudwatch, args.region, args.contact_id, args.cw_stream)
    else:
        hyps = load_hyps_contactlens(args.hyps_contactlens)

    print(f"Loaded {len(refs)} references and {len(hyps)} hypotheses.")
    print(f"Metrics engine: {METRICS_SOURCE}")

    # CloudWatch hypotheses have no per-phrase sequence from the agent. Because
    # phrases can be dropped/mis-ordered during a call, content-based
    # best-match alignment is the safe default (it won't cascade off one
    # dropped phrase the way positional does).
    align_mode = args.align
    if args.hyps_cloudwatch and align_mode == "sequence":
        align_mode = "best-match"
        print("Note: using content-based (best-match) alignment for CloudWatch source.")

    pairs = align(refs, hyps, align_mode)
    scored = score_pairs(pairs)
    agg = aggregate(scored)

    out_csv = args.out_prefix + ".csv"
    out_xlsx = args.out_prefix + ".xlsx"
    write_csv(scored, out_csv)
    write_xlsx(scored, agg, out_xlsx)

    print_summary(agg)
    print(f"Wrote: {out_csv}")
    print(f"Wrote: {out_xlsx}")

    if args.upload_s3:
        upload_to_s3([out_csv, out_xlsx], args.upload_s3)


def upload_to_s3(paths: list[str], s3_uri: str):
    """Upload result files to s3://bucket/prefix/."""
    try:
        import boto3
    except ImportError:
        print("  (boto3 not installed; skipping S3 upload)")
        return
    if not s3_uri.startswith("s3://"):
        print(f"  (invalid S3 URI '{s3_uri}'; skipping upload)")
        return
    without = s3_uri[len("s3://"):]
    bucket, _, prefix = without.partition("/")
    prefix = prefix.strip("/")
    s3 = boto3.client("s3")
    stamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    for p in paths:
        base = os.path.basename(p)
        key = f"{prefix}/{stamp}/{base}" if prefix else f"{stamp}/{base}"
        try:
            s3.upload_file(p, bucket, key)
            print(f"Uploaded: s3://{bucket}/{key}")
        except Exception as exc:  # noqa: BLE001
            print(f"  S3 upload failed for {p}: {exc}")


if __name__ == "__main__":
    main()
