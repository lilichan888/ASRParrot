#!/usr/bin/env python3
"""
make_test_audio_tagalog.py — Generate WAV files for the first N Tagalog
reference phrases using Cartesia (Filipino voice), for a parrot ASR smoke test.

The parrot test measures DEEPGRAM ASR accuracy. These Cartesia-generated WAVs
are just independent test *input* (different vendor from the ASR under test).

Reads phrases from the xlsx GroundTruth column via wer_cer.load_refs_xlsx.
"""
import argparse, csv, os, sys
import wer_cer as w

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--refs-xlsx", required=True)
    ap.add_argument("--count", type=int, default=5)
    ap.add_argument("--out-dir", default="test_audio")
    ap.add_argument("--voice-id", default="8bfb1d08-a77a-4a7c-a4b7-af377380c6eb")  # Joy (Filipino, F) - same voice as the hotline TTS
    ap.add_argument("--model-id", default="sonic-3.5")
    ap.add_argument("--env-file", required=True)
    args = ap.parse_args()

    # api key
    key = None
    for line in open(args.env_file, encoding="utf-8"):
        if line.startswith("CARTESIA_API_KEY"):
            key = line.split("=", 1)[1].strip().strip('"').strip("'")
            break
    if not key:
        sys.exit("No CARTESIA_API_KEY in env file")

    refs = w.load_refs_xlsx(args.refs_xlsx)[:args.count]
    os.makedirs(args.out_dir, exist_ok=True)
    from cartesia import Cartesia
    client = Cartesia(api_key=key)

    print(f"Generating {len(refs)} WAVs with Cartesia voice {args.voice_id} (Tagalog, model {args.model_id})...")
    for seq, phrase, *_ in refs:
        out = os.path.join(args.out_dir, f"phrase_{seq:02d}.wav")
        print(f"  [{seq}] {phrase[:60]}")
        try:
            audio = client.tts.bytes(
                model_id=args.model_id,
                transcript=phrase,
                voice={"mode": "id", "id": args.voice_id},
                language="tl",
                output_format={"container": "wav", "encoding": "pcm_s16le", "sample_rate": 44100},
            )
            with open(out, "wb") as f:
                f.write(b"".join(audio))
            print(f"       -> {out}")
        except Exception as e:
            print(f"       FAILED: {e}")

    idx = os.path.join(args.out_dir, "index.txt")
    with open(idx, "w", encoding="utf-8") as f:
        for seq, phrase, *_ in refs:
            f.write(f"phrase_{seq:02d}.wav\t{phrase}\n")
    print(f"Index: {idx}")

if __name__ == "__main__":
    main()
