#!/usr/bin/env python3
"""
num_normalize.py — Convert spoken number-words into digit strings so ASR
hypotheses that SPELL numbers out compare fairly against digit-based ground
truth.

For the Tagalog/GCash test, callers and Deepgram overwhelmingly render numbers
in ENGLISH ("zero nine one seven...", "one hundred thousand pesos", "three
thirty PM"), because Filipino speakers habitually say numbers, dates, and money
in English even mid-Tagalog-sentence. This module therefore normalizes ENGLISH
number-words. It also strips separators from existing digit runs so
"0917-345-6789" and "09173456789" compare equal.

Applied identically to references AND hypotheses, so any systematic quirk
cancels out. It's a scoring aid, not a perfect NLU.

Handles:
  - digit-by-digit:  "zero nine one seven three four five" -> "0917345"
    (also "oh" -> 0, "double seven" -> "77")
  - magnitude:       "one hundred thousand" -> "100000"
                     "three hundred eighty four thousand" -> "384000"
  - existing digits: "0917-345-6789" -> "09173456789"; "100,000" -> "100000"
"""

import re
import unicodedata

ONES = {
    # English
    "zero": 0, "oh": 0, "o": 0, "nought": 0,
    "one": 1, "two": 2, "three": 3, "four": 4, "five": 5,
    "six": 6, "seven": 7, "eight": 8, "nine": 9,
    "ten": 10, "eleven": 11, "twelve": 12, "thirteen": 13, "fourteen": 14,
    "fifteen": 15, "sixteen": 16, "seventeen": 17, "eighteen": 18, "nineteen": 19,
    # Tagalog / Filipino single digits (canonical base forms only; ASR
    # mis-spellings / glued variants are handled by FUZZY matching below).
    "wala": 0, "sero": 0,
    "isa": 1,
    "dalawa": 2,
    "tatlo": 3,
    "apat": 4,
    "lima": 5,
    "anim": 6,
    "pito": 7,
    "walo": 8,
    "siyam": 9,
}

# Canonical Tagalog digit words used for FUZZY matching of ASR variants
# (e.g. "nanim"->anim, "dalawao"->dalawa, "tito"->pito, "walao"->walo,
# "sio"->siyam, "siyampo"->siyam). Longer words tolerate more edits.
TL_CANON = {
    "wala": 0, "sero": 0, "isa": 1, "dalawa": 2, "tatlo": 3, "apat": 4,
    "lima": 5, "anim": 6, "pito": 7, "walo": 8, "siyam": 9,
}


def _edit_distance(a, b):
    """Levenshtein distance."""
    if a == b:
        return 0
    la, lb = len(a), len(b)
    if la == 0:
        return lb
    if lb == 0:
        return la
    prev = list(range(lb + 1))
    for i, ca in enumerate(a, 1):
        cur = [i]
        for j, cb in enumerate(b, 1):
            cur.append(min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (ca != cb)))
        prev = cur
    return prev[lb]


def _fuzzy_tagalog_digit(token):
    """Return the digit (0-9) if `token` is a close phonetic match to a
    canonical Tagalog digit word, else None. Threshold scales with word length
    so short words (isa, pito) require an exact or near-exact match while longer
    ones (dalawa, siyam) tolerate one edit. Also strips a trailing glued 'po'/'o'
    that Deepgram commonly appends."""
    t = token.strip(".,;:!?()[]{}\"'`-/").lower()
    if not t or t.isdigit():
        return None
    # exact canonical
    if t in TL_CANON:
        return TL_CANON[t]
    # strip a trailing glued particle ("siyampo"->"siyam", "walao"->"wala"/"walo")
    for suf in ("po", "ng", "na", "o", "n"):
        if t.endswith(suf) and t[:-len(suf)] in TL_CANON:
            return TL_CANON[t[:-len(suf)]]
    best, best_d = None, 99
    for w, d in TL_CANON.items():
        dist = _edit_distance(t, w)
        # allow ~1 edit per 4 chars of the canonical word, min 1, capped at 2
        thr = max(1, min(2, len(w) // 4 + 1))
        if dist <= thr and dist < best_d:
            best_d, best = dist, d
    return best
TENS = {
    "twenty": 20, "thirty": 30, "forty": 40, "fourty": 40, "fifty": 50,
    "sixty": 60, "seventy": 70, "eighty": 80, "ninety": 90,
}
SCALES = {"hundred": 100, "thousand": 1_000, "million": 1_000_000, "billion": 1_000_000_000}
MULT = {"double": 2, "triple": 3}

NUMWORDS = set(ONES) | set(TENS) | set(SCALES) | set(MULT) | {"and"}


def _norm(t):
    return unicodedata.normalize("NFC", t or "").lower()


def _has_scale(tokens):
    return any(t in SCALES for t in tokens)


def _parse_magnitude(tokens):
    """Parse an English magnitude number run -> int."""
    total = 0
    current = 0
    for t in tokens:
        if t in ONES:
            current += ONES[t]
        elif t in TENS:
            current += TENS[t]
        elif t == "hundred":
            current = (current or 1) * 100
        elif t in ("thousand", "million", "billion"):
            total += (current or 1) * SCALES[t]
            current = 0
        elif t == "and":
            continue
    return total + current


def _parse_digitseq(tokens):
    """Parse a run of single-digit / teen words digit-by-digit, honoring
    'double'/'triple' multipliers. '-> string of digits'."""
    out = []
    i = 0
    n = len(tokens)
    while i < n:
        t = tokens[i]
        if t in MULT and i + 1 < n and tokens[i + 1] in ONES and ONES[tokens[i + 1]] < 10:
            out.append(str(ONES[tokens[i + 1]]) * MULT[t])
            i += 2
            continue
        if t in ONES:
            v = ONES[t]
            out.append(str(v))  # includes teens as-is (e.g. 'fifteen'->'15')
        elif t in TENS:
            out.append(str(TENS[t]))
        i += 1
    return "".join(out)


def convert(text: str) -> str:
    t = _norm(text)
    # normalize currency/symbol noise
    t = (t.replace("₱", " ").replace("php", " ")
           .replace("pesos", " ").replace("peso", " ").replace("piso", " "))
    raw = re.split(r"\s+", t)
    tokens = [x for x in raw if x != ""]

    def core_of(tok):
        return tok.strip(".,;:!?()[]{}\"'`-/")

    def is_number_token(tok):
        """A token counts as a number token if it's a known number word, a
        digit, or a FUZZY Tagalog digit."""
        c = core_of(tok)
        if c in NUMWORDS and c != "and":
            return True
        if re.search(r"\d", c):
            return True
        if _fuzzy_tagalog_digit(c) is not None:
            return True
        return False

    def token_to_digits(tok):
        """Convert a single number token to its digit string (for digit-seq)."""
        c = core_of(tok)
        if c in ONES:
            return str(ONES[c])
        if c in TENS:
            return str(TENS[c])
        if re.search(r"\d", c):
            return re.sub(r"[.\-,_ ]", "", c)
        fz = _fuzzy_tagalog_digit(c)
        if fz is not None:
            return str(fz)
        return ""

    out = []
    i = 0
    n = len(tokens)
    while i < n:
        # A number run starts only if the token is a CONFIRMED number word or a
        # literal digit (not a fuzzy-only match on its own — that avoids
        # converting a stray real word). Fuzzy Tagalog digits are absorbed once
        # we're already inside a run.
        core = core_of(tokens[i])
        starts_run = (core in NUMWORDS and core != "and") or bool(re.search(r"\d", core))
        if starts_run:
            j = i
            run = []
            while j < n and is_number_token(tokens[j]):
                cj = core_of(tokens[j])
                if cj == "and":
                    break
                run.append(tokens[j])
                j += 1
            while run and core_of(run[-1]) == "and":
                run.pop(); j -= 1
            if not run:
                out.append(tokens[i]); i += 1; continue
            run_cores = [core_of(x) for x in run]
            if _has_scale(run_cores):
                out.append(str(_parse_magnitude(run_cores)))
            else:
                # digit-by-digit, honoring double/triple multipliers
                digits = []
                k = 0
                m = len(run)
                while k < m:
                    ck = run_cores[k]
                    if ck in MULT and k + 1 < m:
                        nxt = token_to_digits(run[k + 1])
                        if len(nxt) == 1:
                            digits.append(nxt * MULT[ck])
                            k += 2
                            continue
                    digits.append(token_to_digits(run[k]))
                    k += 1
                out.append("".join(digits))
            i = j
        else:
            out.append(tokens[i]); i += 1

    result = re.sub(r"\s+", " ", " ".join(out)).strip()
    return result


if __name__ == "__main__":
    tests = [
        # English
        ("zero nine one seven three four five six seven eight nine", "09173456789"),
        ("0917-345-6789", "09173456789"),
        ("one hundred thousand", "100000"),
        ("100,000", "100000"),
        ("double seven eight", "778"),
        ("oh nine one seven", "0917"),
        # Tagalog single digits (clean)
        ("wala siyam pito tatlo apat lima anim pito", "09734567"),
        ("isa dalawa tatlo apat", "1234"),
        # Tagalog with ASR glued/mis-spelled variants (FUZZY should catch these)
        # siyang->9 isang->1 tatlo->3 apat->4 lima->5 nanim->6 tito->7 siyampo->9
        ("wala siyang isang tatlo apat lima nanim tito siyampo", "091345679"),
        ("wala dalawao pito anim lima apat tatlo dalawa", "02765432"),
        # prose must NOT be mangled (no number run starter present)
        ("salamat po sa tulong", "salamat po sa tulong"),
        ("landline po namin wala dalawao pito anim lima apat tatlo dalawa",
         "landline po namin 02765432"),
    ]
    for src, exp in tests:
        got = convert(src)
        print(f"[{'OK ' if got==exp else 'DIFF'}] {src!r} -> {got!r}" + ("" if got==exp else f"  exp {exp!r}"))
