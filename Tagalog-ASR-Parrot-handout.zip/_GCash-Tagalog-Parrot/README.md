# GCash Tagalog Parrot — ASR Test for Amazon Connect Agentic Voice

A "parrot" ASR-accuracy test for **Tagalog / Filipino**, mirroring the finalized
TCB Vietnamese parrot. A human tester reads Tagalog phrases from a fixed list;
Connect Agentic Voice does STT (Deepgram) and TTS. The agent does **not** repeat
the phrase back and calls **no tool** — it just paces the tester with the cue
"Please speak". The Deepgram transcript is captured automatically from
CloudWatch, then scored against the known phrases to produce CER / WER.

Built on the proven `sg-demo-2` instance for testing, then cloned to the
Philippines colleague's instance.

```
Instance (test) : sg-demo-2  e038b142-d31e-4844-b091-5bc9705e43dd
Region          : ap-southeast-1
Account         : 632783683777
Profile         : aseansgconnect
```

---

## How it works (identical architecture to the TCB Vietnamese parrot)

```
Tester reads a Tagalog phrase   (= REFERENCE, from references.csv)
      │  speech
      ▼
Amazon Connect Agentic Voice
   • Deepgram  → speech-to-text  (= HYPOTHESIS)
   • Agent "Loro" → says only "Please speak" (no parrot, no tool)
      │
      ▼
Deepgram hypothesis auto-logged to CloudWatch:
   /aws/wisdom/assistant/<assistantId>  (each CUSTOMER turn = a hypothesis)
      │
      ▼
scoring/wer_cer.py  → CER/WER vs references   (best-match alignment)
scoring/compare_engines.py → Deepgram vs Amazon Transcribe (Contact Lens)
```

No Lambda, DynamoDB, or logging tool — Deepgram output is read straight from the
Q-in-Connect (wisdom) CloudWatch transcript log. Contact Lens (Amazon Transcribe)
runs in parallel on the same audio for the engine comparison.

---

## Repository layout

```
_GCash-Tagalog-Parrot/
├── README.md                                    ← this file
├── references/
│   ├── references.csv                           ← 44 Tagalog phrases (sequence, reference, ...)
│   └── references.txt
├── agent/
│   └── GCash_Tagalog_Parrot_Prompt.json         ← AI agent system prompt ("Loro")
├── connect/
│   └── GCash_Tagalog_Parrot_Flow.json           ← contact flow (has REPLACE_WITH_* placeholders)
└── scoring/
    ├── wer_cer.py                               ← Deepgram CER/WER scoring
    ├── compare_engines.py                       ← Deepgram vs Amazon Transcribe
    ├── num_normalize.py                         ← ENGLISH number-word → digit normalizer
    ├── requirements.txt
    └── .venv/
```

---

## Language facts (verified)

- Tagalog/Filipino **is supported** by Amazon Connect Agentic Voice (and AI Agents).
  Source: https://docs.aws.amazon.com/connect/latest/adminguide/supported-languages.html
- Docs language code: `tl_PH`. In the **contact flow** use the hyphenated form **`tl-PH`**
  (matching how Vietnamese `vi_VN` was written `vi-VN`).
- **Numbers are spoken in ENGLISH** by Filipino callers ("zero nine one seven…",
  "one hundred thousand pesos", "April 15, 1983"). This is the key difference
  from the Vietnamese test — see the scoring section.

---

## Deployment on sg-demo-2 (test instance)

The steps mirror the TCB build. Console steps can't be scripted (Q in Connect AI
agents are console-created); the flow + number are CLI-friendly.

### Step 1 — Create the AI agent (console)
1. Amazon Connect console → **Q in Connect / Amazon Q** → **AI agents**.
2. Create a **Self-service / Agentic Voice** agent named **`GCash-Tagalog-Parrot`**.
3. Paste the system prompt from `agent/GCash_Tagalog_Parrot_Prompt.json`.
4. STT: Deepgram (Agentic Voice default). Language: **Tagalog (tl-PH)**.
5. Publish. Copy these ARNs:
   - **Wisdom Assistant ARN** — `arn:aws:wisdom:...:assistant/<id>`
   - **AI agent version ARN** — `arn:aws:wisdom:...:ai-agent/<assistantId>/<agentId>:$LATEST`

> The parrot agent uses NO tools (unlike TCB's early builds) — just the prompt.

### Step 2 — Find the Tagalog Agentic Voice name + Lex bot alias (console)
1. In a contact flow, add a **Set voice** block → Voice Provider **Amazon Connect
   agentic voice** → Language **Tagalog** → note the **voice name** shown
   (this is the Tagalog equivalent of Vietnamese "LINH"). This value is NOT in
   the docs and can only be read from the dropdown.
2. Agentic Voice is fronted by a Lex V2 bot alias that carries the AI-agent ARN.
   Note its **bot alias ARN**: `arn:aws:lex:...:bot-alias/<botId>/<aliasId>`.
   (For TCB this was a `tl_PH`… no — the VN one was `vi_VN`; you'll need a bot
   whose locale includes **tl_PH**, or the platform-provided agentic bot.)

### Step 3 — Fill placeholders + import the flow
Edit `connect/GCash_Tagalog_Parrot_Flow.json`, replacing:
| Placeholder | Value |
|---|---|
| `REPLACE_WITH_WISDOM_ASSISTANT_ARN` | Wisdom Assistant ARN (Step 1) |
| `REPLACE_WITH_AI_AGENT_ARN` | AI agent version ARN (Step 1) |
| `REPLACE_WITH_LEX_BOT_ALIAS_ARN` | Lex bot alias ARN (Step 2) |
| `REPLACE_WITH_TAGALOG_AGENTIC_VOICE` | Tagalog voice name (Step 2) |

Then create the flow (CLI):
```bash
export AWS_PROFILE=aseansgconnect
aws connect create-contact-flow --region ap-southeast-1 \
  --instance-id e038b142-d31e-4844-b091-5bc9705e43dd \
  --name "GCash-Tagalog-Parrot-Flow" --type CONTACT_FLOW \
  --content file://connect/GCash_Tagalog_Parrot_Flow.json
```
Then **publish** it (console, or `update-contact-flow-content` + publish).

### Step 4 — Attach a phone number
Reuse a spare number on sg-demo-2 (the readme in the source folder references
**+65 60377668**, the same hotline used for TCB — if you reuse it, you'll be
swapping which flow that number points to, so consider a separate number to keep
both parrots callable):
```bash
aws connect associate-phone-number-contact-flow --region ap-southeast-1 \
  --instance-id e038b142-d31e-4844-b091-5bc9705e43dd \
  --phone-number-id <PHONE_NUMBER_ID> --contact-flow-id <GCASH_FLOW_ID>
```

### Step 5 — Confirm CloudWatch logging on the assistant
Deepgram capture depends on the wisdom transcript log group existing for the
GCash assistant. If the new assistant has a different ID than TCB's
(`2b3dbb96-…`), set up the log delivery for it (same 3-step
`put-delivery-source` / `put-delivery-destination` / `create-delivery` as TCB),
targeting `/aws/wisdom/assistant/<gcash-assistantId>`.

---

## Run a test call

1. Tester calls the GCash hotline number.
2. Hears "Please start speaking" (flow greeting).
3. Reads phrase 1 from `references/references.csv` → agent says "Please speak" →
   reads phrase 2 → and so on. Speak one phrase, pause clearly, wait for the cue.
4. Note the **contactId** (Console → Contact search).

Brief the tester: **speak numbers naturally in English** (as Filipinos do) — the
scoring handles that.

---

## Scoring

Setup (once):
```bash
cd scoring
python3 -m venv .venv && ./.venv/bin/pip install -r requirements.txt
```

### Deepgram CER/WER
```bash
./.venv/bin/python wer_cer.py \
  --refs-csv ../references/references.csv \
  --hyps-cloudwatch /aws/wisdom/assistant/<GCASH-ASSISTANT-ID> \
  --contact-id <CID> --region ap-southeast-1 \
  --align best-match \
  --number-mode words2digits \
  --out-prefix results/call_<CID>
```

### Deepgram vs Amazon Transcribe (Contact Lens)
Contact Lens post-call analysis lands in the instance's S3 bucket under
`Analysis/Voice/.../<contactId>_analysis_*.json`. Download it, then:
```bash
./.venv/bin/python compare_engines.py \
  --refs-csv ../references/references.csv \
  --deepgram-cloudwatch /aws/wisdom/assistant/<GCASH-ASSISTANT-ID> --contact-id <CID> \
  --transcribe-json <path-to-analysis.json> \
  --region ap-southeast-1 \
  --out-prefix results/compare_<CID>
```

### Reading results (IMPORTANT for Tagalog)
Filipino callers say numbers in **English**, so Deepgram may output either digits
or English words ("one hundred thousand"). The scorer's **`--number-mode
words2digits`** converts English number-words → digits on BOTH sides via
`num_normalize.py`, so a spelled-out number and a typed number compare equal.
- Use the **number-normalized** CER/WER columns for true recognition accuracy.
- Use **CER micro (corpus)** as the trustworthy headline aggregate; macro can be
  skewed by short phrases.
- `--align best-match` handles dropped/mis-ordered/garbled phrases (two-pass:
  anchor by word overlap, then gap-fill).
- Always eyeball the per-utterance CSV: `Captured? = MISSING` = phrase not spoken
  or not confidently placed.

---

## Cloning to the Philippines colleague's Connect instance

Once validated on sg-demo-2, replicate on the PH instance. Everything is
portable except the instance-specific ARNs and resource IDs.

1. **AI agent**: recreate `GCash-Tagalog-Parrot` in the PH instance's Q in
   Connect (paste the same `agent/GCash_Tagalog_Parrot_Prompt.json`). Publish.
   Get the new assistant + agent ARNs.
2. **Tagalog voice + Lex bot alias**: get these from the PH instance's console
   (voice names/bot aliases are per-instance).
3. **Contact flow**: take `connect/GCash_Tagalog_Parrot_Flow.json`, fill the 4
   placeholders with the PH instance's ARNs/voice, `create-contact-flow` on the
   PH instance, publish.
4. **Phone number**: claim/attach a PH (`+63`) number to the flow on the PH
   instance.
5. **CloudWatch logging**: enable wisdom transcript log delivery for the PH
   assistant (so Deepgram capture works there).
6. **Contact Lens**: confirm the recording/analytics block's `AnalyticsLanguage`
   is `tl-PH` and the PH instance has an S3 analytics bucket configured.
7. **Scoring**: unchanged — just point `--hyps-cloudwatch` at the PH assistant's
   log group and use the PH instance's Contact Lens S3 bucket for the comparison.
8. **Region check**: if the PH instance is in a different region, confirm
   Agentic Voice + Tagalog are available there (it's not in Africa Cape Town /
   GovCloud; all commercial APAC/US regions are fine).

The references, prompt, scoring scripts, and `num_normalize.py` are 100%
reusable as-is.

---

## Honest caveats / lessons carried over from TCB

- **Tagalog voice name is unverified** — I couldn't read it from the API; you
  must get it from the console Set Voice dropdown. The flow has a placeholder.
- **`num_normalize.py` handles English numbers**, which is the expected Filipino
  pattern, but if Deepgram outputs Tagalog native numerals ("isa, dalawa…") those
  won't normalize. Sanity-check number-heavy rows after the first real call; I
  can extend the normalizer with native Tagalog numerals if needed.
- **Best-match alignment** can mark a badly-garbled phrase MISSING or mis-slot a
  phrase if few turns are captured. Clean 1:1 turns (live human, clear pauses)
  give the most trustworthy numbers — same as TCB.
- **Live-call telephony/Agentic Voice usage costs apply**; unanswered ring time
  is not billed, connected minutes are.
- This has **not been deployed or test-called yet** — the flow/prompt/scoring are
  built and locally validated, but a real call on the created agent is the true
  proof (as it was for TCB).
```
